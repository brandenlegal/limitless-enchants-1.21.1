package com.branden.limitlessenchants;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LimitlessEnchants implements ModInitializer {
	public static final String MOD_ID = "limitlessenchants";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Item ENCHANTMENT_CODEX;

	@Override
	public void onInitialize() {
		LOGGER.info("Limitless Enchants loaded: anvil limits, enchanting-table caps and enchantment level caps removed.");
		// Load config (per-enchantment toggles + tuning).
		ModConfig.load();
		// Enchantment Codex item.
		ENCHANTMENT_CODEX = Registry.register(BuiltInRegistries.ITEM,
				RL.of(MOD_ID, "enchantment_codex"),
				new CodexItem(new Item.Properties()));
		// Soulbound: give stashed items back to the new player entity after a death respawn
		// ("alive" is true when returning from the End, which is not a death).
		ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
			if (!alive) {
				SoulboundStash.restore(newPlayer);
			}
		});
		// Put the Codex in the Ingredients creative tab (Fabric API event — no mixin needed).
		ResourceKey<CreativeModeTab> ingredients = ResourceKey.create(Registries.CREATIVE_MODE_TAB,
				ResourceLocation.fromNamespaceAndPath("minecraft", "ingredients"));
		ItemGroupEvents.modifyEntriesEvent(ingredients)
				.register(entries -> entries.accept(ENCHANTMENT_CODEX));
	}
}
