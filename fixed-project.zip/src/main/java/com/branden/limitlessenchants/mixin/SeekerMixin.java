package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Seeker (bow): arrows curve toward the nearest living target within
 * 8 + 4 blocks per level. Only for player-shot arrows.
 */
@Mixin(AbstractArrow.class)
public abstract class SeekerMixin {
	@Shadow
	protected boolean inGround;
	@Inject(method = "tick", at = @At("HEAD"))
	private void limitless$seekerHoming(CallbackInfo ci) {
		AbstractArrow self = (AbstractArrow) (Object) this;
		if (!(self.level() instanceof ServerLevel level)) {
			return;
		}
		if (this.inGround) {
			return;
		}
		Entity owner = self.getOwner();
		if (!(owner instanceof ServerPlayer player)) {
			return;
		}
		// Check the bow used. AbstractArrow doesn't track it directly;
		// check mainhand/offhand for a Seeker bow.
		int seeker = ModConfig.isEnabled("seeker") ? Math.max(
				EnchantHolders.level(level, "seeker", player.getMainHandItem()),
				EnchantHolders.level(level, "seeker", player.getOffhandItem())) : 0;
		if (seeker <= 0) {
			return;
		}
		double range = Math.min(8.0 + 4.0 * seeker, 48.0);
		// Throttle the entity scan — every 4 ticks is plenty for homing.
		if (self.tickCount % 4 != 0) {
			return;
		}
		AABB box = self.getBoundingBox().inflate(range);
		LivingEntity target = null;
		double best = Double.MAX_VALUE;
		for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box,
				e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
			double d = self.distanceToSqr(e);
			if (d < best) {
				best = d;
				target = e;
			}
		}
		if (target == null) {
			return;
		}
		// Curve velocity toward the target's chest. Clamped so extreme
		// levels bend harder without ever inverting the arrow.
		double turn = Math.min(0.15 * seeker, 0.85);
		Vec3 toTarget = new Vec3(target.getX() - self.getX(),
				(target.getY() + target.getBbHeight() * 0.5) - self.getY(),
				target.getZ() - self.getZ()).normalize();
		Vec3 vel = self.getDeltaMovement();
		double speed = vel.length();
		Vec3 curved = vel.normalize().scale(1.0 - turn).add(toTarget.scale(turn)).normalize()
				.scale(speed);
		self.setDeltaMovement(curved);
	}
}
