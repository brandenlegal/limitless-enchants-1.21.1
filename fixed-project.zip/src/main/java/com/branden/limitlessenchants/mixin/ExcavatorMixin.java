package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.VeinMineHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Excavator: breaking a block with an Excavator-enchanted tool also breaks a 3x3
 * plane of blocks around it, oriented to the direction being mined. Higher levels
 * dig deeper (level 2 = 3x3x2, level 3 = 3x3x3, ...).
 */
@Mixin(ServerPlayerGameMode.class)
public abstract class ExcavatorMixin {
	@Shadow
	@Final
	protected ServerPlayer player;

	@Shadow
	protected ServerLevel level;

	@Shadow
	public abstract boolean destroyBlock(BlockPos pos);

	@Unique
	private boolean limitless$excavating = false;

	@Inject(method = "destroyBlock", at = @At("RETURN"))
	private void limitless$excavatorBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
		if (!cir.getReturnValue() || limitless$excavating) {
			return;
		}
		// Sneak for precision: disables the 3x3 when you need single blocks.
		if (player.isCrouching()) {
			return;
		}
		ItemStack tool = player.getMainHandItem();
		if (!ModConfig.isEnabled("excavator")) {
			return;
		}
		int excavatorLevel = EnchantHolders.level(level, "excavator", tool);
		if (excavatorLevel <= 0) {
			return;
		}
		// Guard: the extra breaks below re-enter destroyBlock, which would
		// re-trigger this handler forever.
		limitless$excavating = true;
		VeinMineHelper.excavatorActive = true;
		try {
			for (BlockPos target : limitless$excavatorTargets(pos,
					Math.min(excavatorLevel, ModConfig.get().excavatorMaxDepth))) {
				if (target.equals(pos)) {
					continue;
				}
				BlockState state = level.getBlockState(target);
				if (state.isAir() || !state.getFluidState().isEmpty()) {
					continue;
				}
				if (state.getDestroySpeed(level, target) < 0.0F) {
					continue; // unbreakable (bedrock, barriers, ...)
				}
				destroyBlock(target);
			}
		} finally {
			limitless$excavating = false;
			VeinMineHelper.excavatorActive = false;
		}
	}


	@Unique
	private List<BlockPos> limitless$excavatorTargets(BlockPos pos, int depth) {
		List<BlockPos> targets = new ArrayList<>();
		float pitch = player.getXRot();
		if (pitch < -50.0F) {
			// Looking up: horizontal layers above the target.
			for (int d = 0; d < depth; d++) {
				for (int dx = -1; dx <= 1; dx++) {
					for (int dz = -1; dz <= 1; dz++) {
						targets.add(pos.offset(dx, d, dz));
					}
				}
			}
		} else if (pitch > 50.0F) {
			// Looking down: horizontal layers below the target.
			for (int d = 0; d < depth; d++) {
				for (int dx = -1; dx <= 1; dx++) {
					for (int dz = -1; dz <= 1; dz++) {
						targets.add(pos.offset(dx, -d, dz));
					}
				}
			}
		} else {
			// Mining sideways: vertical plane facing the player, extending inward.
			Direction facing = player.getDirection();
			boolean xAxis = facing.getAxis() == Direction.Axis.X;
			for (int d = 0; d < depth; d++) {
				BlockPos center = pos.relative(facing, d);
				for (int a = -1; a <= 1; a++) {
					for (int b = -1; b <= 1; b++) {
						targets.add(xAxis ? center.offset(0, a, b) : center.offset(a, b, 0));
					}
				}
			}
		}
		return targets;
	}
}
