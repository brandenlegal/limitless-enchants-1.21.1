package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import com.branden.limitlessenchants.RL;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Limitless Fortune: vanilla Fortune ignores crops like sugar cane, cactus,
 * bamboo and kelp. This removes that limit — Fortune now multiplies their
 * drops too (1 + level per block, so Fortune III = 4x). Crops that vanilla
 * Fortune already affects (wheat, carrots, potatoes...) are untouched to
 * avoid double-dipping.
 */
@Mixin(Block.class)
public class FortuneCropsMixin {
	@Unique
	private static final TagKey<Block> LIMITLESS$FORTUNE_CROPS = TagKey.create(Registries.BLOCK, RL.of("limitlessenchants", "fortune_crops"));

	@Inject(
		method = "getDrops(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;",
		at = @At("RETURN")
	)
	private static void limitless$fortuneCrops(BlockState state, ServerLevel level, BlockPos pos,
			BlockEntity blockEntity, Entity breaker, ItemStack tool,
			CallbackInfoReturnable<List<ItemStack>> cir) {
		if (!state.is(LIMITLESS$FORTUNE_CROPS)) {
			return;
		}
		// Nerf: only multiply if the plant is actually grown (has the same
		// plant above it). Prevents plant-1-break-1 infinite duplication.
		if (!level.getBlockState(pos.above()).is(state.getBlock())) {
			return;
		}
		int fortune = EnchantHolders.vanillaLevel(level, Enchantments.FORTUNE, tool);
		if (fortune <= 0) {
			return;
		}
		java.util.List<ItemStack> drops = cir.getReturnValue();
		java.util.List<ItemStack> overflow = new java.util.ArrayList<>();
		for (ItemStack stack : drops) {
			if (!stack.isEmpty()) {
				int total = stack.getCount() * (1 + fortune);
				int max = stack.getMaxStackSize();
				if (total <= max) {
					stack.setCount(total);
				} else {
					// Cap at max stack; spill overflow as extra stacks.
					stack.setCount(max);
					int remaining = total - max;
					while (remaining > 0) {
						int take = Math.min(remaining, max);
						ItemStack extra = stack.copy();
						extra.setCount(take);
						overflow.add(extra);
						remaining -= take;
					}
				}
			}
		}
		drops.addAll(overflow);
	}

}
