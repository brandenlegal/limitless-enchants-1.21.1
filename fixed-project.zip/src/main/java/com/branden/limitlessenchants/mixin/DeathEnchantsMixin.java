package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.core.component.DataComponents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.storage.loot.LootParams;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Death-triggered enchantments:
 * - Phoenix (chestplate): cheat death once — restore to half health, fire
 *   burst, 5-minute cooldown per level reduction.
 * - Beheader (weapon): 15% + 10% per level chance for mobs to drop their head.
 * - Sear (weapon): mob food drops come out cooked.
 */
@Mixin(LivingEntity.class)
public class DeathEnchantsMixin {
	@Unique
	private static final Map<UUID, Long> limitless$phoenixCooldown = new ConcurrentHashMap<>();

	/**
	 * Phoenix: intercept lethal damage.
	 */
	@Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
	private void limitless$phoenixCheck(DamageSource source, float amount,
			CallbackInfoReturnable<Boolean> cir) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (!(self instanceof ServerPlayer player)) {
			return;
		}
		ServerLevel level = (ServerLevel) self.level();
		// Would this kill them?
		if (player.getHealth() - amount > 0) {
			return;
		}
		// Don't save from unavoidable damage (void, etc.).
		if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
			return;
		}
		ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
		int phoenix = ModConfig.isEnabled("phoenix") ? EnchantHolders.level(level, "phoenix", chest) : 0;
		if (phoenix <= 0) {
			return;
		}
		long now = level.getGameTime();
		long last = limitless$phoenixCooldown.getOrDefault(player.getUUID(), 0L);
		long cooldown = (ModConfig.get().phoenixCooldownSeconds * 20L) / phoenix;
		if (now - last < cooldown) {
			return;
		}
		limitless$phoenixCooldown.put(player.getUUID(), now);

		// Cheat death: restore half health, brief fire resistance + regen.
		cir.cancel();
		cir.setReturnValue(false);
		player.setHealth(player.getMaxHealth() * 0.5F);
		player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 10 * 20, 0));
		player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 10 * 20, 1));
		// Fire burst visual.
		for (int i = 0; i < 30; i++) {
			double dx = (level.getRandom().nextDouble() - 0.5) * 2.0;
			double dz = (level.getRandom().nextDouble() - 0.5) * 2.0;
			level.sendParticles(net.minecraft.core.particles.ParticleTypes.FLAME,
					player.getX(), player.getY() + 1, player.getZ(), 1, dx, 0.5, dz, 0.1);
		}
		// Phoenix cry.
		level.playSound(null, player.getX(), player.getY(), player.getZ(),
				net.minecraft.sounds.SoundEvents.TOTEM_USE,
				net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 1.2F);
	}

	/**
	 * Beheader + Sear: modify death drops.
	 */
	@Inject(method = "dropAllDeathLoot", at = @At("RETURN"))
	private void limitless$deathLootMods(ServerLevel level, DamageSource source, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (!(source.getEntity() instanceof ServerPlayer player)) {
			return;
		}
		ItemStack weapon = player.getMainHandItem();

		// Beheader: chance for head drop.
		int beheader = ModConfig.isEnabled("beheader") ? EnchantHolders.level(level, "beheader", weapon) : 0;
		if (beheader > 0 && level.getRandom().nextFloat() < 0.15F + 0.10F * beheader) {
			ItemStack head = limitless$headFor(self.getType());
			if (!head.isEmpty()) {
				ItemEntity drop = new ItemEntity(level, self.getX(), self.getY(), self.getZ(), head);
				level.addFreshEntity(drop);
			}
		}

		// Sear: this is handled via loot table modification is complex;
		// instead, we convert raw meat drops already on the ground nearby.
		// (Simplified: Sear cooks food items dropped within 3 blocks.)
		int sear = ModConfig.isEnabled("sear") ? EnchantHolders.level(level, "sear", weapon) : 0;
		if (sear > 0) {
			for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class,
					self.getBoundingBox().inflate(3.0))) {
				ItemStack stack = item.getItem();
				if (limitless$isRawMeat(stack)) {
					var recipe = level.getRecipeManager()
							.getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(stack), level);
					if (recipe.isPresent()) {
						ItemStack cooked = recipe.get().value().assemble(new SingleRecipeInput(stack), level.registryAccess());
						if (!cooked.isEmpty()) {
							cooked.setCount(stack.getCount());
							item.setItem(cooked);
						}
					}
				}
			}
		}
	}

	@Unique
	private static ItemStack limitless$headFor(EntityType<?> type) {
		// Map common mobs to their heads.
		String id = EntityType.getKey(type).toString();
		if (id.contains("zombie") && !id.contains("piglin")) {
			return new ItemStack(Items.ZOMBIE_HEAD);
		} else if (id.contains("skeleton") && !id.contains("wither")) {
			return new ItemStack(Items.SKELETON_SKULL);
		} else if (id.contains("wither_skeleton")) {
			return new ItemStack(Items.WITHER_SKELETON_SKULL);
		} else if (id.contains("creeper")) {
			return new ItemStack(Items.CREEPER_HEAD);
		} else if (id.contains("piglin")) {
			return new ItemStack(Items.PIGLIN_HEAD);
		} else if (id.contains("dragon")) {
			return new ItemStack(Items.DRAGON_HEAD);
		}
		return ItemStack.EMPTY;
	}

	@Unique
	private static boolean limitless$isRawMeat(ItemStack stack) {
		return stack.is(Items.BEEF) || stack.is(Items.PORKCHOP) || stack.is(Items.CHICKEN)
				|| stack.is(Items.MUTTON) || stack.is(Items.RABBIT) || stack.is(Items.COD)
				|| stack.is(Items.SALMON);
	}
}
