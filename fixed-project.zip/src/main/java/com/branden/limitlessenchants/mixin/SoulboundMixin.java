package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.SoulboundStash;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Soulbound: items with this enchantment are kept on death instead of being
 * dropped. They are stashed (keyed by player UUID, since the player entity is
 * recreated on respawn) before vanilla drops the inventory, and restored when
 * the new player entity spawns.
 */
@Mixin(Player.class)
public abstract class SoulboundMixin {
	@Inject(method = "dropEquipment", at = @At("HEAD"))
	private void limitless$soulboundKeep(CallbackInfo ci) {
		Player self = (Player) (Object) this;
		ServerLevel level = (ServerLevel) self.level();
		// keepInventory handles everything — nothing for us to do.
		if (level.getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) {
			return;
		}
		List<ItemStack> stashed = new ArrayList<>();
		Inventory inventory = self.getInventory();
		boolean soulboundOn = ModConfig.isEnabled("soulbound");
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.getItem(i);
			if (!stack.isEmpty() && soulboundOn
					&& EnchantHolders.level(level, "soulbound", stack) > 0) {
				stashed.add(stack.copy());
				inventory.setItem(i, ItemStack.EMPTY);
			}
		}
		if (!stashed.isEmpty() && self instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
			SoulboundStash.put(level.getServer(), self.getUUID(), stashed);
		}
	}

}
