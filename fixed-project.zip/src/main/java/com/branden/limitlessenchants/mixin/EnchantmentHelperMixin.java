package com.branden.limitlessenchants.mixin;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/**
 * Removes the enchanting table's limits:
 * - bookshelves past 15 keep raising the offered XP costs (and the enchantment power behind them),
 * - offered enchantment levels can exceed the vanilla maximum when there is enough power.
 * Kept vanilla: the table still filters enchantments by item type (books get everything),
 * and selectEnchantment() is untouched.
 */
@Mixin(EnchantmentHelper.class)
public class EnchantmentHelperMixin {
	/**
	 * @author Branden
	 * @reason Uncapped bookshelves: every shelf past 15 pours in much more power, so a
	 * maxed-out setup can reach god-tier levels. The XP price climbs with it — that's the deal.
	 */
	@Overwrite
	public static int getEnchantmentCost(RandomSource random, int slot, int bookcases, ItemStack itemStack) {
		// Same gate vanilla uses: items with no enchantability can't be enchanted.
		if (itemStack.getItem().getEnchantmentValue() <= 0) {
			return 0;
		}
		int selected = random.nextInt(8) + 1 + (bookcases >> 1) + random.nextInt(bookcases + 1);
		int over = bookcases - 15;
		if (over > 0) {
			selected += over * 4 + random.nextInt(over * 4 + 1);
		}
		if (slot == 0) {
			return Math.max(selected / 3, 1);
		} else {
			return slot == 1 ? selected * 2 / 3 + 1 : Math.max(selected, bookcases * 2);
		}
	}

	/**
	 * @author Branden
	 * @reason Lets the table offer levels above the vanilla maximum: the per-level cost
	 * formulas scale linearly, so the search walks upward past the vanilla max while
	 * the available power covers the cost, then picks the best level with the exact
	 * same rule vanilla uses.
	 */
	@Overwrite
	public static List<EnchantmentInstance> getAvailableEnchantmentResults(
			int value, ItemStack itemStack, Stream<Holder<Enchantment>> source) {
		List<EnchantmentInstance> results = Lists.newArrayList();
		boolean isBook = itemStack.is(Items.BOOK);
		source.filter(holder -> holder.value().isPrimaryItem(itemStack) || isBook).forEach(holder -> {
			Enchantment enchantment = holder.value();
			int topLevel = enchantment.getMaxLevel();
			// Walk up past the vanilla max while the power covers the cost.
			// Bounded so flat cost curves can't loop forever, and capped at 255
			// (the highest level ItemEnchantments can store).
			while (topLevel < Enchantment.MAX_LEVEL
					&& topLevel - enchantment.getMaxLevel() < value + 64
					&& enchantment.getMinCost(topLevel + 1) <= value) {
				topLevel++;
			}
			for (int level = topLevel; level >= enchantment.getMinLevel(); level--) {
				if (value >= enchantment.getMinCost(level) && value <= enchantment.getMaxCost(level)) {
					results.add(new EnchantmentInstance(holder, level));
					break;
				}
			}
		});
		return results;
	}
}
