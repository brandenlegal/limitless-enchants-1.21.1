package com.branden.limitlessenchants.mixin;

import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Removes the anvil's limits:
 * - no more "Too Expensive!" (any XP cost is allowed),
 * - enchantment levels can merge past the vanilla maximum (Sharpness V + Sharpness V = Sharpness VI, ...),
 * - the prior-work penalty no longer grows, so repeated anvil uses never snowball in cost.
 */
@Mixin(AnvilMenu.class)
public class AnvilMenuMixin {
	// 1.21.1 createResult() has two `cost >= 40` checks: one that clamps the cost to
	// 39 and one that voids the output unless the player is in creative. Raising the
	// threshold removes both without touching anything else.
	@ModifyConstant(method = "createResult", constant = @Constant(intValue = 40))
	private int limitless$removeTooExpensiveCutoff(int original) {
		return Integer.MAX_VALUE;
	}

	// createResult() clamps merged levels with `if (level > enchantment.getMaxLevel())`.
	// Returning the game's hard level ceiling (255, the most ItemEnchantments can
	// store) removes the vanilla clamp so levels can grow far past e.g. Sharpness V.
	@Redirect(
		method = "createResult",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/enchantment/Enchantment;getMaxLevel()I"
		)
	)
	private int limitless$noMaxLevelCap(Enchantment enchantment) {
		return Enchantment.MAX_LEVEL;
	}

	// Vanilla doubles the repair cost (plus one) after every anvil operation and adds it
	// to the XP price, which is what makes costs snowball. Keep it flat instead.
	@Inject(method = "calculateIncreasedRepairCost", at = @At("HEAD"), cancellable = true)
	private static void limitless$flatRepairCost(int baseCost, CallbackInfoReturnable<Integer> cir) {
		cir.setReturnValue(baseCost);
	}

	// Universal enchanting: any item can be used in the anvil, not just
	// items the game considers enchantable.
	@Redirect(
		method = "createResult",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;canStoreEnchantments(Lnet/minecraft/world/item/ItemStack;)Z"
		)
	)
	private boolean limitless$anyItemInAnvil(ItemStack itemStack) {
		return true;
	}
}
