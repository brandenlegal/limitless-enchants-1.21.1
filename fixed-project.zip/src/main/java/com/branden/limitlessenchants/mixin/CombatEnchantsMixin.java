package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Combat enchantments, triggered whenever a player successfully damages something:
 * - Lifesteal: heal for 10% of the damage dealt per level.
 * - Thunderstrike: 25% chance per level to call down lightning on the victim.
 * - Poison Aspect: inflict poison (6s + 3s per level).
 * - Execute: 50% bonus damage per level to targets below 20% health.
 * - Frostbite: slow the victim (20% + 10% per level, 5s) and deal 2 damage per level over 4s.
 * - Adrenaline: gain Speed II for 6s (+2s per level) on kill.
 * - Dodge: 10% chance per level (on chestplate) to completely avoid incoming damage.
 */
@Mixin(LivingEntity.class)
public class CombatEnchantsMixin {
	@Unique
	private static boolean limitless$striking;

	@Unique
	private static boolean limitless$executing;

	@Unique
	private static boolean limitless$inCombatHandler;

	/**
	 * Dodge: checked BEFORE damage is applied. If it procs, the hit is
	 * completely avoided.
	 */
	@Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
	private void limitless$dodgeCheck(DamageSource source, float amount,
			CallbackInfoReturnable<Boolean> cir) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (!(self.level() instanceof ServerLevel level)) {
			return;
		}
		if (!(self instanceof ServerPlayer player)) {
			return;
		}
		// Dodge is on the chestplate.
		ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
		int dodge = ModConfig.isEnabled("dodge") ? EnchantHolders.level(level, "dodge", chest) : 0;
		// Cap at 80% — Dodge 10 shouldn't mean permanent invincibility.
		if (dodge > 0 && level.getRandom().nextFloat() < Math.min(0.10F * dodge, 0.80F)) {
			cir.setReturnValue(false);
			cir.cancel();
			// Poof + sound on dodge.
			level.sendParticles(net.minecraft.core.particles.ParticleTypes.CLOUD,
					player.getX(), player.getY() + 1, player.getZ(), 12, 0.5, 0.5, 0.5, 0.1);
			level.playSound(null, player.getX(), player.getY(), player.getZ(),
					net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_SWEEP,
					net.minecraft.sounds.SoundSource.PLAYERS, 0.5F, 1.5F);
		}
	}

	/**
	 * Execute: checked BEFORE damage. If the victim is below 20% HP, the
	 * damage is multiplied and re-applied.
	 */
	@Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
	private void limitless$executeCheck(DamageSource source, float amount,
			CallbackInfoReturnable<Boolean> cir) {
		if (limitless$executing) {
			return;
		}
		if (!(source.getEntity() instanceof ServerPlayer player)) {
			return;
		}
		LivingEntity victim = (LivingEntity) (Object) this;
		if (!(victim.level() instanceof ServerLevel level)) {
			return;
		}
		if (victim.getHealth() / victim.getMaxHealth() >= 0.20F) {
			return;
		}
		ItemStack weapon = player.getMainHandItem();
		int execute = ModConfig.isEnabled("execute") ? EnchantHolders.level(level, "execute", weapon) : 0;
		if (execute <= 0) {
			return;
		}
		limitless$executing = true;
		try {
			boolean result = victim.hurt(source, amount * (1.0F + 0.5F * execute));
			cir.setReturnValue(result);
			// Crit burst on execute.
			level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
					victim.getX(), victim.getY() + 1, victim.getZ(), 15, 0.5, 0.5, 0.5, 0.2);
		} finally {
			limitless$executing = false;
		}
		cir.cancel();
	}

	@Inject(method = "hurt", at = @At("RETURN"))
	private void limitless$combatEnchants(DamageSource source, float amount,
			CallbackInfoReturnable<Boolean> cir) {
		if (!cir.getReturnValue() || limitless$striking || limitless$inCombatHandler) {
			return;
		}
		if (!(source.getEntity() instanceof ServerPlayer player)) {
			return;
		}
		LivingEntity victim = (LivingEntity) (Object) this;
		if (!(victim.level() instanceof ServerLevel level)) {
			return;
		}
		ItemStack weapon = player.getMainHandItem();

		// Guard: Frostbite deals damage, which would re-enter this handler.
		limitless$inCombatHandler = true;
		try {
			int lifesteal = ModConfig.isEnabled("lifesteal")
				? EnchantHolders.level(level, "lifesteal", weapon) : 0;
		if (lifesteal > 0) {
			player.heal(amount * 0.1F * lifesteal);
			// Green wisps on heal.
			level.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
					player.getX(), player.getY() + 1.5, player.getZ(), 5, 0.3, 0.3, 0.3, 0.1);
		}

		int thunder = ModConfig.isEnabled("thunderstrike")
				? EnchantHolders.level(level, "thunderstrike", weapon) : 0;
		if (thunder > 0 && level.getRandom().nextFloat() < 0.25F * thunder) {
			// Visual-only bolt: flash + thunder sound, but no damage and no
			// fires, so it can't zap the wielder or burn builds down.
			LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, level);
			bolt.setVisualOnly(true);
			bolt.setPos(victim.getX(), victim.getY(), victim.getZ());
			level.addFreshEntity(bolt);
			limitless$striking = true;
			try {
				victim.hurt(level.damageSources().lightningBolt(), 5.0F);
			} finally {
				limitless$striking = false;
			}
		}

		int poison = ModConfig.isEnabled("poison_aspect") ? EnchantHolders.level(level, "poison_aspect", weapon) : 0;
		if (poison > 0) {
			victim.addEffect(new MobEffectInstance(MobEffects.POISON, (6 + 3 * poison) * 20, poison - 1));
		}

		int frost = ModConfig.isEnabled("frostbite") ? EnchantHolders.level(level, "frostbite", weapon) : 0;
		if (frost > 0) {
			victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5 * 20, Math.min(frost, 3)));
			// Damage over time: 2 per level, applied as magic damage.
			victim.hurt(level.damageSources().magic(), 2.0F * frost);
		}

		// Adrenaline: speed burst on kill.
		if (!victim.isAlive()) {
			int adrenaline = ModConfig.isEnabled("adrenaline")
					? EnchantHolders.level(level, "adrenaline", player.getItemBySlot(EquipmentSlot.FEET)) : 0;
			if (adrenaline > 0) {
				player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, (6 + 2 * adrenaline) * 20, 1));
			}
		}
		} finally {
			limitless$inCombatHandler = false;
		}
	}
}
