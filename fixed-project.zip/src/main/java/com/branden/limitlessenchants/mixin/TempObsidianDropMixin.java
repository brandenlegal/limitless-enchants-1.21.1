package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.TempObsidianTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lava Walker's temporary platforms are a convenience, not a quarry —
 * breaking one drops nothing.
 */
@Mixin(Block.class)
public class TempObsidianDropMixin {
	@Inject(
		method = "dropResources(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)V",
		at = @At("HEAD"),
		cancellable = true
	)
	private static void limitless$noTempObsidianDrops(BlockState state, Level level, BlockPos pos,
			BlockEntity blockEntity, Entity breaker, ItemStack tool, CallbackInfo ci) {
		if (TempObsidianTracker.isTemp(level.dimension(), pos)) {
			TempObsidianTracker.remove(level.dimension(), pos);
			ci.cancel();
		}
	}
}
