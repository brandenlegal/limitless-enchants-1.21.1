package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.VeinMineHelper;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Tree Feller (axe only): breaking a log also breaks all connected logs
 * (up to 64 blocks), felling the whole tree.
 */
@Mixin(ServerPlayerGameMode.class)
public abstract class TreeFellerMixin {
	@Shadow
	@Final
	protected ServerPlayer player;

	@Shadow
	protected ServerLevel level;

	@Unique
	private final java.util.Map<BlockPos, BlockState> limitless$choppedStates = new java.util.HashMap<>();

	@Inject(method = "destroyBlock", at = @At("HEAD"))
	private void limitless$treeFellerCapture(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
		limitless$choppedStates.put(pos.immutable(), level.getBlockState(pos));
	}

	@Inject(method = "destroyBlock", at = @At("RETURN"))
	private void limitless$treeFellerBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
		BlockState centerState = limitless$choppedStates.remove(pos.immutable());
		if (centerState == null) {
			return;
		}
		if (!cir.getReturnValue()) {
			return;
		}
		if (VeinMineHelper.excavatorActive) {
			return;
		}
		ItemStack tool = player.getMainHandItem();
		if (!ModConfig.isEnabled("tree_feller")) {
			return;
		}
		if (EnchantHolders.level(level, "tree_feller", tool) <= 0) {
			return;
		}
		if (!centerState.is(BlockTags.LOGS)) {
			return;
		}
		// Flood with 26-neighbor connectivity (catches diagonal branches),
		// tracking the lowest log for replanting.
		java.util.Set<BlockPos> brokenLogs = new java.util.HashSet<>();
		limitless$floodTreeLogs(pos, tool, brokenLogs);
		int broken = brokenLogs.size();
		if (broken > 0) {
			player.displayClientMessage(Component.literal("Tree felled! " + broken + " logs"), true);
			// Leaves are left alone — vanilla decay handles them naturally.
			// Auto-replant a sapling at the BASE of the tree (lowest log), not mid-air.
			if (ModConfig.get().treeFellerReplant) {
				BlockPos replantPos = limitless$findReplantPos(brokenLogs);
				if (replantPos != null) {
					limitless$replantSapling(replantPos, centerState);
				}
			}
		}
	}

	/**
	 * Finds the replant position: the northwest corner (min X, min Z)
	 * at the lowest Y among broken logs. For 2x2 trees, this aligns
	 * the sapling pattern with the original trunk.
	 */
	@Unique
	private BlockPos limitless$findReplantPos(java.util.Set<BlockPos> brokenLogs) {
		BlockPos best = null;
		for (BlockPos p : brokenLogs) {
			if (best == null || p.getY() < best.getY()
					|| (p.getY() == best.getY() && (p.getX() < best.getX()
							|| (p.getX() == best.getX() && p.getZ() < best.getZ())))) {
				best = p;
			}
		}
		return best;
	}

	/**
	 * Flood-fills all connected logs using 26-neighbor connectivity.
	 */
	@Unique
	private void limitless$floodTreeLogs(BlockPos startPos, ItemStack tool, java.util.Set<BlockPos> brokenLogs) {
		java.util.Set<BlockPos> visited = new java.util.HashSet<>();
		java.util.Deque<BlockPos> queue = new java.util.ArrayDeque<>();
		// 26 neighbors (3x3x3 minus center)
		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					if (dx == 0 && dy == 0 && dz == 0) continue;
					queue.add(startPos.offset(dx, dy, dz));
				}
			}
		}
		int cap = 256; // higher cap for big trees
		while (!queue.isEmpty() && brokenLogs.size() < cap) {
			if (tool.isEmpty()) {
				break;
			}
			BlockPos current = queue.poll();
			if (!visited.add(current.immutable())) {
				continue;
			}
			BlockState state = level.getBlockState(current);
			if (!state.is(BlockTags.LOGS)) {
				continue;
			}
			if (state.getDestroySpeed(level, current) < 0.0F) {
				continue;
			}
			// Break it directly (no destroyBlock recursion).
			Block.dropResources(state, level, current, level.getBlockEntity(current), player, tool);
			level.setBlock(current, Blocks.AIR.defaultBlockState(), 3);
			tool.hurtAndBreak(1, level, player, (stack) -> {
			});
			brokenLogs.add(current.immutable());
			// Add 26 neighbors
			for (int dx = -1; dx <= 1; dx++) {
				for (int dy = -1; dy <= 1; dy++) {
					for (int dz = -1; dz <= 1; dz++) {
						if (dx == 0 && dy == 0 && dz == 0) continue;
						queue.add(current.offset(dx, dy, dz));
					}
				}
			}
		}
	}

	@Unique
	private void limitless$replantSapling(BlockPos pos, BlockState logState) {
		Block sapling = limitless$saplingFor(logState.getBlock());
		if (sapling == null) {
			return;
		}
		// Don't plant in mid-air — the block below must be solid (dirt, grass, etc).
		// If the lowest log was floating (shouldn't happen), skip replant.
		BlockPos below = pos.below();
		BlockState belowState = level.getBlockState(below);
		if (!belowState.isSolidRender(level, below)) {
			return;
		}
		// 2x2 trees (dark oak, jungle) need a 2x2 sapling pattern to regrow.
		if (limitless$is2x2Tree(logState.getBlock())) {
			BlockPos[] pattern = { pos, pos.east(), pos.south(), pos.east().south() };
			boolean clear = true;
			for (BlockPos p : pattern) {
				if (!level.getBlockState(p).isAir()) {
					clear = false;
					break;
				}
			}
			if (clear) {
				for (BlockPos p : pattern) {
					level.setBlock(p, sapling.defaultBlockState(), 3);
				}
			}
			return;
		}
		// Only replant if the spot is clear.
		if (level.getBlockState(pos).isAir()) {
			level.setBlock(pos, sapling.defaultBlockState(), 3);
		}
	}

	@Unique
	private static Block limitless$saplingFor(Block log) {
		// Regular logs.
		if (log == Blocks.OAK_LOG) return Blocks.OAK_SAPLING;
		if (log == Blocks.SPRUCE_LOG) return Blocks.SPRUCE_SAPLING;
		if (log == Blocks.BIRCH_LOG) return Blocks.BIRCH_SAPLING;
		if (log == Blocks.JUNGLE_LOG) return Blocks.JUNGLE_SAPLING;
		if (log == Blocks.ACACIA_LOG) return Blocks.ACACIA_SAPLING;
		if (log == Blocks.DARK_OAK_LOG) return Blocks.DARK_OAK_SAPLING;
		if (log == Blocks.MANGROVE_LOG) return Blocks.MANGROVE_PROPAGULE;
		if (log == Blocks.CHERRY_LOG) return Blocks.CHERRY_SAPLING;
		// Stripped variants replant the same sapling.
		if (log == Blocks.STRIPPED_OAK_LOG) return Blocks.OAK_SAPLING;
		if (log == Blocks.STRIPPED_SPRUCE_LOG) return Blocks.SPRUCE_SAPLING;
		if (log == Blocks.STRIPPED_BIRCH_LOG) return Blocks.BIRCH_SAPLING;
		if (log == Blocks.STRIPPED_JUNGLE_LOG) return Blocks.JUNGLE_SAPLING;
		if (log == Blocks.STRIPPED_ACACIA_LOG) return Blocks.ACACIA_SAPLING;
		if (log == Blocks.STRIPPED_DARK_OAK_LOG) return Blocks.DARK_OAK_SAPLING;
		if (log == Blocks.STRIPPED_MANGROVE_LOG) return Blocks.MANGROVE_PROPAGULE;
		if (log == Blocks.STRIPPED_CHERRY_LOG) return Blocks.CHERRY_SAPLING;
		return null;
	}

	/**
	 * Returns true if this log is from a 2x2 tree (dark oak, jungle).
	 * Single-sapling replant can't regrow those, so we plant the 2x2 pattern.
	 */
	@Unique
	private static boolean limitless$is2x2Tree(Block log) {
		return log == Blocks.DARK_OAK_LOG || log == Blocks.STRIPPED_DARK_OAK_LOG
				|| log == Blocks.JUNGLE_LOG || log == Blocks.STRIPPED_JUNGLE_LOG;
	}

}
