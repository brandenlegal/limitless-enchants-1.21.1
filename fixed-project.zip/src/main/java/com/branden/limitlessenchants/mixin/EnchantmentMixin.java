package com.branden.limitlessenchants.mixin;

import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Makes every enchantment compatible with every other enchantment, so the anvil
 * and the enchanting table can combine things like Sharpness + Smite or
 * Silk Touch + Fortune that vanilla forbids.
 */
@Mixin(Enchantment.class)
public class EnchantmentMixin {
	@Inject(method = "areCompatible", at = @At("HEAD"), cancellable = true)
	private static void limitless$allEnchantmentsCompatible(
			Holder<Enchantment> first, Holder<Enchantment> second, CallbackInfoReturnable<Boolean> cir) {
		// Keep an enchantment incompatible with itself so the enchanting table
		// never offers the same enchantment twice on a single item.
		if (!first.equals(second)) {
			cir.setReturnValue(true);
		}
	}

	// Vanilla only translates enchantment.level.1 through .10; without this,
	// levels past 10 would render as the raw key ("enchantment.level.11").
	// Show the plain number instead (e.g. "Sharpness 11").
	@Redirect(
		method = "getFullname",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/network/chat/Component;translatable(Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent;"
		)
	)
	private static MutableComponent limitless$levelNumber(String key) {
		final String prefix = "enchantment.level.";
		if (key.startsWith(prefix)) {
			try {
				if (Integer.parseInt(key.substring(prefix.length())) > 10) {
					return Component.literal(key.substring(prefix.length()));
				}
			} catch (NumberFormatException ignored) {
				// fall through to vanilla behavior
			}
		}
		return Component.translatable(key);
	}
}
