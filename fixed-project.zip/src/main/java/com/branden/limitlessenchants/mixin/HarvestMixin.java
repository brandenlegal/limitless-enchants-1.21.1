package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Harvest (hoe): breaking a fully-grown crop automatically replants it.
 */
@Mixin(Block.class)
public class HarvestMixin {
	@Inject(method = "playerDestroy", at = @At("HEAD"))
	private void limitless$harvestReplant(Level level, Player player, BlockPos pos,
			BlockState state, BlockEntity blockEntity, ItemStack tool, CallbackInfo ci) {
		if (!(level instanceof ServerLevel serverLevel)) {
			return;
		}
		if (!(player instanceof ServerPlayer serverPlayer)) {
			return;
		}
		if (!(state.getBlock() instanceof CropBlock crop)) {
			return;
		}
		if (!crop.isMaxAge(state)) {
			return;
		}
		int harvest = ModConfig.isEnabled("harvest") ? EnchantHolders.level(serverLevel, "harvest", tool) : 0;
		if (harvest <= 0) {
			return;
		}
		// Replant after destruction. Defer one tick so we don't fight the break.
		BlockPos replantPos = pos.immutable();
		BlockState seedling = crop.defaultBlockState(); // age 0 for crops
		serverLevel.getServer().execute(() -> {
			if (serverLevel.getBlockState(replantPos).isAir()) {
				serverLevel.setBlock(replantPos, seedling, 3);
			}
		});
	}
}
