package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Bulwark (chestplate): generates a shield absorbing 4 damage per level.
 * Shield regenerates 1 point every 5 seconds out of combat. Damage hits
 * the shield first.
 */
@Mixin(LivingEntity.class)
public class BulwarkMixin {
	@Unique
	private static final Map<UUID, Float> limitless$shield = new ConcurrentHashMap<>();

	@Unique
	private static final Map<UUID, Long> limitless$lastRegen = new ConcurrentHashMap<>();

	@Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
	private void limitless$bulwarkAbsorb(DamageSource source, float amount,
			CallbackInfoReturnable<Boolean> cir) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (!(self.level() instanceof ServerLevel level)) {
			return;
		}
		if (!(self instanceof ServerPlayer player)) {
			return;
		}
		// Don't shield unavoidable damage (void, etc.).
		if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
			return;
		}
		ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
		int bulwark = ModConfig.isEnabled("bulwark") ? EnchantHolders.level(level, "bulwark", chest) : 0;
		if (bulwark <= 0) {
			return;
		}
		float maxShield = 4.0F * bulwark;
		UUID id = player.getUUID();

		// Regen scales with time away: 1 point per 5s out of combat,
		// catching up fully after long breaks.
		long now = level.getGameTime();
		long last = limitless$lastRegen.getOrDefault(id, 0L);
		float current = limitless$shield.getOrDefault(id, maxShield);
		long elapsed = now - last;
		if (elapsed >= 5 * 20) {
			long points = elapsed / (5 * 20);
			current = Math.min(maxShield, current + points);
			limitless$lastRegen.put(id, now);
			limitless$shield.put(id, current);
		}

		if (current <= 0) {
			return;
		}
		float absorbed = Math.min(current, amount);
		limitless$shield.put(id, current - absorbed);
		float remaining = amount - absorbed;
		if (remaining <= 0) {
			// Fully absorbed.
			cir.setReturnValue(false);
			cir.cancel();
		} else {
			// Partially absorbed — re-apply reduced damage, honestly
			// reporting whatever the inner call decides.
			cir.cancel();
			cir.setReturnValue(self.hurt(source, remaining));
		}
	}
}
