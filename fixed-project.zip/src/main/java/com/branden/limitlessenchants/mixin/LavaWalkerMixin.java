package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.TempObsidianTracker;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lava Walker (boots): walking over lava creates temporary cooled-obsidian
 * platforms (radius 2 + level) that melt back after 8 seconds. Platforms are
 * tracked per-dimension and never drop items (no obsidian farming).
 */
@Mixin(ServerPlayer.class)
public class LavaWalkerMixin {
	@Inject(method = "tick", at = @At("HEAD"))
	private void limitless$lavaWalk(CallbackInfo ci) {
		ServerPlayer self = (ServerPlayer) (Object) this;
		if (!(self.level() instanceof ServerLevel level)) {
			return;
		}
		long now = level.getGameTime();

		// Melt expired platforms back to lava (on their own dimension).
		if (self.tickCount % 20 == 0) {
			MinecraftServer server = level.getServer();
			List<TempObsidianTracker.DimPos> expired = TempObsidianTracker.takeExpired(now, 8 * 20);
			for (TempObsidianTracker.DimPos dimPos : expired) {
				ServerLevel dimLevel = server.getLevel(dimPos.dimension());
				if (dimLevel == null) {
					continue;
				}
				BlockPos pos = dimPos.pos();
				if (dimLevel.getBlockState(pos).is(Blocks.OBSIDIAN)) {
					dimLevel.setBlock(pos, Blocks.LAVA.defaultBlockState(), 3);
				}
			}
		}

		if (self.tickCount % 4 != 0) {
			return;
		}
		ItemStack boots = self.getItemBySlot(EquipmentSlot.FEET);
		int lavaWalker = ModConfig.isEnabled("lava_walker") ? EnchantHolders.level(level, "lava_walker", boots) : 0;
		if (lavaWalker <= 0) {
			return;
		}
		if (!self.onGround() && !self.isInLava()) {
			return;
		}
		ResourceKey<Level> dimension = level.dimension();
		BlockPos center = self.blockPosition();
		int radius = 2 + lavaWalker;
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dz = -radius; dz <= radius; dz++) {
				if (dx * dx + dz * dz > radius * radius) {
					continue;
				}
				BlockPos pos = center.offset(dx, -1, dz);
				BlockState state = level.getBlockState(pos);
				if (state.getFluidState().is(Fluids.LAVA) && state.getFluidState().isSource()) {
					level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), 3);
					TempObsidianTracker.put(dimension, pos, now);
				}
			}
		}
	}
}
