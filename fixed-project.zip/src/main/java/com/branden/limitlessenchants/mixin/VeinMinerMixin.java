package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.VeinMineHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import com.branden.limitlessenchants.RL;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Vein Miner: breaking an ore also breaks the whole connected vein
 * (up to 64 blocks) of the same ore type.
 */
@Mixin(ServerPlayerGameMode.class)
public abstract class VeinMinerMixin {
	@Shadow
	@Final
	protected ServerPlayer player;

	@Shadow
	protected ServerLevel level;

	@Unique
	private static final TagKey<Block> LIMITLESS$VEIN_MINEABLE = TagKey.create(Registries.BLOCK, RL.of("limitlessenchants", "vein_mineable"));

	@Unique
	private final java.util.Map<BlockPos, BlockState> limitless$minedStates = new java.util.HashMap<>();

	// The center block is gone by the time destroyBlock returns, so capture
	// what it was up front. Position-keyed map handles re-entrancy (Excavator)
	// and self-heals if HEAD/RETURN desync.
	@Inject(method = "destroyBlock", at = @At("HEAD"))
	private void limitless$veinMinerCapture(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
		limitless$minedStates.put(pos.immutable(), level.getBlockState(pos));
	}

	@Inject(method = "destroyBlock", at = @At("RETURN"))
	private void limitless$veinMinerBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
		BlockState centerState = limitless$minedStates.remove(pos.immutable());
		if (centerState == null) {
			return;
		}
		if (!cir.getReturnValue()) {
			return;
		}
		// Don't vein-mine blocks broken by Excavator's 3x3 — that would
		// trigger a 64-block vein per excavated ore (exponential explosion).
		if (VeinMineHelper.excavatorActive) {
			return;
		}
		ItemStack tool = player.getMainHandItem();
		if (!ModConfig.isEnabled("vein_miner")) {
			return;
		}
		if (EnchantHolders.level(level, "vein_miner", tool) <= 0) {
			return;
		}
		if (!centerState.is(LIMITLESS$VEIN_MINEABLE)) {
			return;
		}
		Block targetBlock = centerState.getBlock();
		int broken = VeinMineHelper.floodMine(level, player, pos, state -> state.is(targetBlock), tool,
				ModConfig.get().veinMinerCap);
		if (broken > 0) {
			player.displayClientMessage(Component.literal("Vein mined! " + broken + " blocks"), true);
		}
	}

}
