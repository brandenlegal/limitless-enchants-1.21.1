package com.branden.limitlessenchants;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/**
 * Tracks Lava Walker's temporary obsidian platforms, keyed by dimension so
 * platforms in one dimension are never melted (or suppressed) in another.
 */
public final class TempObsidianTracker {
	private TempObsidianTracker() {
	}

	public record DimPos(ResourceKey<Level> dimension, BlockPos pos) {
	}

	private static final Map<DimPos, Long> PLATFORMS = new ConcurrentHashMap<>();

	public static void put(ResourceKey<Level> dimension, BlockPos pos, long gameTime) {
		PLATFORMS.put(new DimPos(dimension, pos.immutable()), gameTime);
	}

	public static boolean isTemp(ResourceKey<Level> dimension, BlockPos pos) {
		return PLATFORMS.containsKey(new DimPos(dimension, pos.immutable()));
	}

	public static void remove(ResourceKey<Level> dimension, BlockPos pos) {
		PLATFORMS.remove(new DimPos(dimension, pos.immutable()));
	}

	/** Removes expired entries, returning them for melting. */
	public static java.util.List<DimPos> takeExpired(long now, long maxAge) {
		java.util.List<DimPos> expired = new java.util.ArrayList<>();
		Iterator<Map.Entry<DimPos, Long>> it = PLATFORMS.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<DimPos, Long> e = it.next();
			if (now - e.getValue() > maxAge) {
				expired.add(e.getKey());
				it.remove();
			}
		}
		return expired;
	}
}
