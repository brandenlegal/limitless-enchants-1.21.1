package com.branden.limitlessenchants;

import net.minecraft.resources.ResourceLocation;

/**
 * Tiny ResourceLocation helpers. Calls the vanilla factory directly — Loom
 * remaps it for production, so no reflection (which can't be remapped) is needed.
 */
public final class RL {
	private RL() {
	}

	public static ResourceLocation of(String namespace, String path) {
		return ResourceLocation.fromNamespaceAndPath(namespace, path);
	}

	public static ResourceLocation mc(String path) {
		return of("minecraft", path);
	}

	public static ResourceLocation mod(String path) {
		return of(LimitlessEnchants.MOD_ID, path);
	}
}
