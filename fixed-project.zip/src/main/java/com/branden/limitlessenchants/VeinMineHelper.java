package com.branden.limitlessenchants;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Shared logic for vein-style enchantments (Vein Miner, Tree Feller):
 * flood-fills connected matching blocks and breaks them directly, so the
 * normal destroyBlock handlers (Excavator etc.) don't re-trigger per block.
 * Drops still go through Block.dropResources, so Fortune, Silk Touch,
 * Auto-Smelt and Telepathy all apply.
 */
public final class VeinMineHelper {
	private VeinMineHelper() {
	}

	/**
	 * Set while Excavator is breaking its extra blocks. Vein Miner and Tree
	 * Feller check this to avoid triggering per excavated block, which would
	 * explode exponentially (64-block vein per excavated ore).
	 */
	public static boolean excavatorActive = false;

	public static int floodMine(ServerLevel level, ServerPlayer player, BlockPos startPos,
			Predicate<BlockState> matches, ItemStack tool, int cap) {
		Set<BlockPos> broken = new HashSet<>();
		return floodMine(level, player, startPos, matches, tool, cap, broken);
	}

	public static int floodMine(ServerLevel level, ServerPlayer player, BlockPos startPos,
			Predicate<BlockState> matches, ItemStack tool, int cap, Set<BlockPos> brokenPositions) {
		Set<BlockPos> visited = new HashSet<>();
		Deque<BlockPos> queue = new ArrayDeque<>();
		for (Direction dir : Direction.values()) {
			queue.add(startPos.relative(dir));
		}
		int broken = 0;
		while (!queue.isEmpty() && broken < cap) {
			if (tool.isEmpty()) {
				break;
			}
			BlockPos current = queue.poll();
			if (!visited.add(current.immutable())) {
				continue;
			}
			BlockState state = level.getBlockState(current);
			if (!matches.test(state)) {
				continue;
			}
			if (state.getDestroySpeed(level, current) < 0.0F) {
				continue;
			}
			breakExtra(level, player, current, state, tool);
			broken++;
			brokenPositions.add(current.immutable());
			for (Direction dir : Direction.values()) {
				queue.add(current.relative(dir));
			}
		}
		return broken;
	}

	private static void breakExtra(ServerLevel level, ServerPlayer player, BlockPos target, BlockState state,
			ItemStack tool) {
		Block.dropResources(state, level, target, level.getBlockEntity(target), player, tool);
		level.setBlock(target, Blocks.AIR.defaultBlockState(), 3);
		tool.hurtAndBreak(1, level, player, (stack) -> {
		});
	}
}
