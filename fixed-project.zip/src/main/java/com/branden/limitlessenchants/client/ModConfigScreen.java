package com.branden.limitlessenchants.client;

import com.branden.limitlessenchants.ModConfig;
import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.OptionGroup;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.IntegerSliderControllerBuilder;
import dev.isxander.yacl3.api.controller.TickBoxControllerBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * YACL-based config screen for Limitless Enchants.
 * Two categories: Enchantments (22 toggles) and Tuning (5 sliders).
 */
public class ModConfigScreen {
	private static final String[] ENCHANT_IDS = {
		"excavator", "vein_miner", "auto_smelt", "tree_feller", "harvest",
		"telepathy", "lifesteal", "thunderstrike", "seeker", "poison_aspect",
		"execute", "beheader", "adrenaline", "frostbite", "sear",
		"phoenix", "dodge", "bulwark", "soulbound", "lava_walker",
		"magnet", "reach"
	};

	private static final String[] ENCHANT_NAMES = {
		"Excavator", "Vein Miner", "Auto-Smelt", "Tree Feller", "Harvest",
		"Telepathy", "Lifesteal", "Thunderstrike", "Seeker", "Poison Aspect",
		"Execute", "Beheader", "Adrenaline", "Frostbite", "Sear",
		"Phoenix", "Dodge", "Bulwark", "Soulbound", "Lava Walker",
		"Magnet", "Reach"
	};

	public static Screen create(Screen parent) {
		ModConfig config = ModConfig.get();

		OptionGroup.Builder enchantGroup = OptionGroup.createBuilder()
				.name(Component.literal("Enchantment Toggles"))
				.description(OptionDescription.of(Component.literal("Turn individual enchantments on or off.")));

		for (int i = 0; i < ENCHANT_IDS.length; i++) {
			final String id = ENCHANT_IDS[i];
			enchantGroup.option(Option.<Boolean>createBuilder()
					.name(Component.literal(ENCHANT_NAMES[i]))
					.description(OptionDescription.of(Component.literal("Enable or disable " + ENCHANT_NAMES[i] + ".")))
					.binding(
							true,
							() -> ModConfig.isEnabled(id),
							v -> config.setEnabled(id, v))
					.controller(TickBoxControllerBuilder::create)
					.build());
		}

		ConfigCategory enchantments = ConfigCategory.createBuilder()
				.name(Component.literal("Enchantments"))
				.group(enchantGroup.build())
				.build();

		ConfigCategory tuning = ConfigCategory.createBuilder()
				.name(Component.literal("Tuning"))
				.group(OptionGroup.createBuilder()
						.name(Component.literal("Balance"))
						.option(Option.<Integer>createBuilder()
								.name(Component.literal("Vein Miner Cap"))
								.description(OptionDescription.of(Component.literal("Max blocks Vein Miner can break at once (16-128).")))
								.binding(64, () -> config.veinMinerCap, v -> config.veinMinerCap = v)
								.controller(opt -> IntegerSliderControllerBuilder.create(opt).range(16, 128).step(1))
								.build())
						.option(Option.<Integer>createBuilder()
								.name(Component.literal("Excavator Depth"))
								.description(OptionDescription.of(Component.literal("How deep Excavator digs per level (1-5).")))
								.binding(5, () -> config.excavatorMaxDepth, v -> config.excavatorMaxDepth = v)
								.controller(opt -> IntegerSliderControllerBuilder.create(opt).range(1, 5).step(1))
								.build())
						.option(Option.<Integer>createBuilder()
								.name(Component.literal("Magnet Radius"))
								.description(OptionDescription.of(Component.literal("Item pickup radius in blocks (4-16).")))
								.binding(6, () -> config.magnetBaseRadius, v -> config.magnetBaseRadius = v)
								.controller(opt -> IntegerSliderControllerBuilder.create(opt).range(4, 16).step(1))
								.build())
						.option(Option.<Boolean>createBuilder()
								.name(Component.literal("Tree Replant"))
								.description(OptionDescription.of(Component.literal("Auto-replant saplings after Tree Feller.")))
								.binding(true, () -> config.treeFellerReplant, v -> config.treeFellerReplant = v)
								.controller(TickBoxControllerBuilder::create)
								.build())
						.option(Option.<Integer>createBuilder()
								.name(Component.literal("Phoenix Cooldown"))
								.description(OptionDescription.of(Component.literal("Seconds before Phoenix can trigger again (30-600).")))
								.binding(300, () -> config.phoenixCooldownSeconds, v -> config.phoenixCooldownSeconds = v)
								.controller(opt -> IntegerSliderControllerBuilder.create(opt).range(30, 600).step(10))
								.build())
						.build())
				.build();

		return YetAnotherConfigLib.createBuilder()
				.title(Component.literal("Limitless Enchants Config"))
				.category(enchantments)
				.category(tuning)
				.save(config::saveToDisk)
				.build()
				.generateScreen(parent);
	}
}
