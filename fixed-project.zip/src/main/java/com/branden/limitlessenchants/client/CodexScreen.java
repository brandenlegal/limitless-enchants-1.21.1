package com.branden.limitlessenchants.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;

/**
 * Opens the Enchantment Codex book GUI (client-only).
 */
@Environment(EnvType.CLIENT)
public class CodexScreen {
	public static void open() {
		Minecraft.getInstance().setScreen(new CodexBookScreen());
	}
}
