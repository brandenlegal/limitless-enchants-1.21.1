package com.branden.limitlessenchants;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Simple config: per-enchantment toggles plus tuning knobs.
 * Stored as a properties file (no external config lib needed).
 * Opened from a button in the Enchantment Codex.
 */
public class ModConfig {
	private static final String FILE_NAME = "limitlessenchants.properties";
	private static ModConfig INSTANCE;

	// ---------- Enchantment toggles ----------
	public boolean excavatorEnabled = true;
	public boolean veinMinerEnabled = true;
	public boolean autoSmeltEnabled = true;
	public boolean treeFellerEnabled = true;
	public boolean harvestEnabled = true;
	public boolean telepathyEnabled = true;
	public boolean lifestealEnabled = true;
	public boolean thunderstrikeEnabled = true;
	public boolean seekerEnabled = true;
	public boolean poisonAspectEnabled = true;
	public boolean executeEnabled = true;
	public boolean beheaderEnabled = true;
	public boolean adrenalineEnabled = true;
	public boolean frostbiteEnabled = true;
	public boolean searEnabled = true;
	public boolean phoenixEnabled = true;
	public boolean dodgeEnabled = true;
	public boolean bulwarkEnabled = true;
	public boolean soulboundEnabled = true;
	public boolean lavaWalkerEnabled = true;
	public boolean magnetEnabled = true;
	public boolean reachEnabled = true;

	// ---------- Tuning ----------
	public int veinMinerCap = 64;
	public int excavatorMaxDepth = 5;
	public int magnetBaseRadius = 6;
	public boolean treeFellerReplant = true;
	public int phoenixCooldownSeconds = 300;

	public static ModConfig get() {
		if (INSTANCE == null) {
			INSTANCE = new ModConfig();
			INSTANCE.loadFromDisk();
		}
		return INSTANCE;
	}

	/** Call once on mod init (loads from disk). */
	public static void load() {
		get();
	}

	private Path filePath() {
		return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
	}

	private void loadFromDisk() {
		try {
			Path path = filePath();
			if (!Files.exists(path)) {
				return;
			}
			Properties p = new Properties();
			try (var in = Files.newInputStream(path)) {
				p.load(in);
			}
			excavatorEnabled = getBool(p, "excavatorEnabled", excavatorEnabled);
			veinMinerEnabled = getBool(p, "veinMinerEnabled", veinMinerEnabled);
			autoSmeltEnabled = getBool(p, "autoSmeltEnabled", autoSmeltEnabled);
			treeFellerEnabled = getBool(p, "treeFellerEnabled", treeFellerEnabled);
			harvestEnabled = getBool(p, "harvestEnabled", harvestEnabled);
			telepathyEnabled = getBool(p, "telepathyEnabled", telepathyEnabled);
			lifestealEnabled = getBool(p, "lifestealEnabled", lifestealEnabled);
			thunderstrikeEnabled = getBool(p, "thunderstrikeEnabled", thunderstrikeEnabled);
			seekerEnabled = getBool(p, "seekerEnabled", seekerEnabled);
			poisonAspectEnabled = getBool(p, "poisonAspectEnabled", poisonAspectEnabled);
			executeEnabled = getBool(p, "executeEnabled", executeEnabled);
			beheaderEnabled = getBool(p, "beheaderEnabled", beheaderEnabled);
			adrenalineEnabled = getBool(p, "adrenalineEnabled", adrenalineEnabled);
			frostbiteEnabled = getBool(p, "frostbiteEnabled", frostbiteEnabled);
			searEnabled = getBool(p, "searEnabled", searEnabled);
			phoenixEnabled = getBool(p, "phoenixEnabled", phoenixEnabled);
			dodgeEnabled = getBool(p, "dodgeEnabled", dodgeEnabled);
			bulwarkEnabled = getBool(p, "bulwarkEnabled", bulwarkEnabled);
			soulboundEnabled = getBool(p, "soulboundEnabled", soulboundEnabled);
			lavaWalkerEnabled = getBool(p, "lavaWalkerEnabled", lavaWalkerEnabled);
			magnetEnabled = getBool(p, "magnetEnabled", magnetEnabled);
			reachEnabled = getBool(p, "reachEnabled", reachEnabled);
			veinMinerCap = getInt(p, "veinMinerCap", veinMinerCap, 16, 128);
			excavatorMaxDepth = getInt(p, "excavatorMaxDepth", excavatorMaxDepth, 1, 5);
			magnetBaseRadius = getInt(p, "magnetBaseRadius", magnetBaseRadius, 4, 16);
			treeFellerReplant = getBool(p, "treeFellerReplant", treeFellerReplant);
			phoenixCooldownSeconds = getInt(p, "phoenixCooldownSeconds", phoenixCooldownSeconds, 30, 600);
		} catch (Exception ignored) {
		}
	}

	public void save() {
		try {
			Properties p = new Properties();
			p.setProperty("excavatorEnabled", Boolean.toString(excavatorEnabled));
			p.setProperty("veinMinerEnabled", Boolean.toString(veinMinerEnabled));
			p.setProperty("autoSmeltEnabled", Boolean.toString(autoSmeltEnabled));
			p.setProperty("treeFellerEnabled", Boolean.toString(treeFellerEnabled));
			p.setProperty("harvestEnabled", Boolean.toString(harvestEnabled));
			p.setProperty("telepathyEnabled", Boolean.toString(telepathyEnabled));
			p.setProperty("lifestealEnabled", Boolean.toString(lifestealEnabled));
			p.setProperty("thunderstrikeEnabled", Boolean.toString(thunderstrikeEnabled));
			p.setProperty("seekerEnabled", Boolean.toString(seekerEnabled));
			p.setProperty("poisonAspectEnabled", Boolean.toString(poisonAspectEnabled));
			p.setProperty("executeEnabled", Boolean.toString(executeEnabled));
			p.setProperty("beheaderEnabled", Boolean.toString(beheaderEnabled));
			p.setProperty("adrenalineEnabled", Boolean.toString(adrenalineEnabled));
			p.setProperty("frostbiteEnabled", Boolean.toString(frostbiteEnabled));
			p.setProperty("searEnabled", Boolean.toString(searEnabled));
			p.setProperty("phoenixEnabled", Boolean.toString(phoenixEnabled));
			p.setProperty("dodgeEnabled", Boolean.toString(dodgeEnabled));
			p.setProperty("bulwarkEnabled", Boolean.toString(bulwarkEnabled));
			p.setProperty("soulboundEnabled", Boolean.toString(soulboundEnabled));
			p.setProperty("lavaWalkerEnabled", Boolean.toString(lavaWalkerEnabled));
			p.setProperty("magnetEnabled", Boolean.toString(magnetEnabled));
			p.setProperty("reachEnabled", Boolean.toString(reachEnabled));
			p.setProperty("veinMinerCap", Integer.toString(veinMinerCap));
			p.setProperty("excavatorMaxDepth", Integer.toString(excavatorMaxDepth));
			p.setProperty("magnetBaseRadius", Integer.toString(magnetBaseRadius));
			p.setProperty("treeFellerReplant", Boolean.toString(treeFellerReplant));
			p.setProperty("phoenixCooldownSeconds", Integer.toString(phoenixCooldownSeconds));
			try (var out = Files.newOutputStream(filePath())) {
				p.store(out, "Limitless Enchants config");
			}
		} catch (IOException ignored) {
		}
	}

	private static boolean getBool(Properties p, String key, boolean def) {
		String v = p.getProperty(key);
		return v == null ? def : Boolean.parseBoolean(v);
	}

	private static int getInt(Properties p, String key, int def, int min, int max) {
		try {
			int v = Integer.parseInt(p.getProperty(key));
			return Math.max(min, Math.min(max, v));
		} catch (Exception e) {
			return def;
		}
	}

	/** Central toggle check — enchantment IDs use snake_case (e.g. "vein_miner"). */
	public static boolean isEnabled(String enchantmentId) {
		ModConfig c = get();
		return switch (enchantmentId) {
			case "excavator" -> c.excavatorEnabled;
			case "vein_miner" -> c.veinMinerEnabled;
			case "auto_smelt" -> c.autoSmeltEnabled;
			case "tree_feller" -> c.treeFellerEnabled;
			case "harvest" -> c.harvestEnabled;
			case "telepathy" -> c.telepathyEnabled;
			case "lifesteal" -> c.lifestealEnabled;
			case "thunderstrike" -> c.thunderstrikeEnabled;
			case "seeker" -> c.seekerEnabled;
			case "poison_aspect" -> c.poisonAspectEnabled;
			case "execute" -> c.executeEnabled;
			case "beheader" -> c.beheaderEnabled;
			case "adrenaline" -> c.adrenalineEnabled;
			case "frostbite" -> c.frostbiteEnabled;
			case "sear" -> c.searEnabled;
			case "phoenix" -> c.phoenixEnabled;
			case "dodge" -> c.dodgeEnabled;
			case "bulwark" -> c.bulwarkEnabled;
			case "soulbound" -> c.soulboundEnabled;
			case "lava_walker" -> c.lavaWalkerEnabled;
			case "magnet" -> c.magnetEnabled;
			case "reach" -> c.reachEnabled;
			default -> true;
		};
	}

	/** Sets an enchantment toggle by ID. */
	public void setEnabled(String enchantmentId, boolean value) {
		switch (enchantmentId) {
			case "excavator" -> this.excavatorEnabled = value;
			case "vein_miner" -> this.veinMinerEnabled = value;
			case "auto_smelt" -> this.autoSmeltEnabled = value;
			case "tree_feller" -> this.treeFellerEnabled = value;
			case "harvest" -> this.harvestEnabled = value;
			case "telepathy" -> this.telepathyEnabled = value;
			case "lifesteal" -> this.lifestealEnabled = value;
			case "thunderstrike" -> this.thunderstrikeEnabled = value;
			case "seeker" -> this.seekerEnabled = value;
			case "poison_aspect" -> this.poisonAspectEnabled = value;
			case "execute" -> this.executeEnabled = value;
			case "beheader" -> this.beheaderEnabled = value;
			case "adrenaline" -> this.adrenalineEnabled = value;
			case "frostbite" -> this.frostbiteEnabled = value;
			case "sear" -> this.searEnabled = value;
			case "phoenix" -> this.phoenixEnabled = value;
			case "dodge" -> this.dodgeEnabled = value;
			case "bulwark" -> this.bulwarkEnabled = value;
			case "soulbound" -> this.soulboundEnabled = value;
			case "lava_walker" -> this.lavaWalkerEnabled = value;
			case "magnet" -> this.magnetEnabled = value;
			case "reach" -> this.reachEnabled = value;
		}
	}

	/** Alias for save() — used by YACL's save hook. */
	public void saveToDisk() {
		this.save();
	}
}
