package com.branden.limitlessenchants;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;

/**
 * Cached Holder&lt;Enchantment&gt; lookups for this mod's enchantments.
 *
 * Dynamic registries are rebuilt every time a world is loaded or datapacks are
 * reloaded, and a Holder from an old registry never matches enchantments on
 * stacks in the new one. So each cache entry remembers the registry instance it
 * came from and is re-resolved whenever that instance changes.
 *
 * Lookups never throw: if the enchantment isn't in the registry (for example a
 * client connected to a server that doesn't have this mod's datapack) the level
 * is simply 0, so hooks like Reach can't crash the game.
 */
public final class EnchantHolders {
	private EnchantHolders() {
	}

	private record Entry(Registry<Enchantment> registry, Optional<Holder<Enchantment>> holder) {
	}

	private static final Map<String, Entry> CACHE = new ConcurrentHashMap<>();

	public static Optional<Holder<Enchantment>> find(Level level, String path) {
		Registry<Enchantment> registry = level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
		Entry cached = CACHE.get(path);
		if (cached != null && cached.registry() == registry) {
			return cached.holder();
		}
		Optional<Holder<Enchantment>> holder = registry
				.getHolder(ResourceKey.create(Registries.ENCHANTMENT, RL.of(LimitlessEnchants.MOD_ID, path)))
				.map(ref -> (Holder<Enchantment>) ref);
		CACHE.put(path, new Entry(registry, holder));
		return holder;
	}

	/** Level of one of this mod's enchantments on a stack (0 if absent, unregistered, or stack empty). */
	public static int level(Level level, String path, ItemStack stack) {
		if (stack.isEmpty()) {
			return 0;
		}
		return find(level, path)
				.map(holder -> EnchantmentHelper.getItemEnchantmentLevel(holder, stack))
				.orElse(0);
	}

	/** Level of a vanilla (or any other namespace) enchantment on a stack. */
	public static int vanillaLevel(Level level, ResourceKey<Enchantment> key, ItemStack stack) {
		if (stack.isEmpty()) {
			return 0;
		}
		return level.registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolder(key)
				.map(holder -> EnchantmentHelper.getItemEnchantmentLevel(holder, stack))
				.orElse(0);
	}
}
