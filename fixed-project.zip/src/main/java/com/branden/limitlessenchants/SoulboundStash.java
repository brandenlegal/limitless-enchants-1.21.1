package com.branden.limitlessenchants;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.LevelResource;

/**
 * Soulbound item stash, keyed by player UUID. The player entity is recreated
 * on respawn, so the stash can't live on the entity itself.
 *
 * Mirrored to an NBT file in the world directory, so a server restart/crash
 * between death and respawn doesn't silently delete god gear.
 */
public final class SoulboundStash {
	private SoulboundStash() {
	}

	private static final Map<UUID, List<ItemStack>> STASH = new HashMap<>();
	private static final String FILE_NAME = "limitlessenchants_soulbound.nbt";

	public static void put(MinecraftServer server, UUID playerId, List<ItemStack> items) {
		STASH.put(playerId, new ArrayList<>(items));
		saveToFile(server);
	}

	public static List<ItemStack> take(MinecraftServer server, UUID playerId) {
		List<ItemStack> items = STASH.remove(playerId);
		if (items != null) {
			saveToFile(server);
			return items;
		}
		// In-memory missed (server restarted?) — try the file backup.
		loadFromFile(server);
		items = STASH.remove(playerId);
		if (items != null) {
			saveToFile(server);
		}
		return items;
	}

	private static Path filePath(MinecraftServer server) {
		return server.getWorldPath(LevelResource.ROOT).resolve(FILE_NAME);
	}

	private static void saveToFile(MinecraftServer server) {
		try {
			CompoundTag root = new CompoundTag();
			var ops = server.registryAccess().createSerializationContext(NbtOps.INSTANCE);
			for (Map.Entry<UUID, List<ItemStack>> entry : STASH.entrySet()) {
				ListTag list = new ListTag();
				for (ItemStack stack : entry.getValue()) {
					try {
						Tag t = ItemStack.CODEC.encodeStart(ops, stack).getOrThrow();
						list.add(t);
					} catch (Exception ignored) {
					}
				}
				root.put(entry.getKey().toString(), list);
			}
			NbtIo.write(root, filePath(server));
		} catch (Exception ignored) {
			// Backup is best-effort; the in-memory stash is authoritative.
		}
	}

	private static void loadFromFile(MinecraftServer server) {
		try {
			Path path = filePath(server);
			if (!Files.exists(path)) {
				return;
			}
			CompoundTag root = NbtIo.read(path);
			if (root == null) {
				return;
			}
			var ops = server.registryAccess().createSerializationContext(NbtOps.INSTANCE);
			for (String key : root.getAllKeys()) {
				try {
					UUID id = UUID.fromString(key);
					if (STASH.containsKey(id)) {
						continue; // in-memory wins
					}
					ListTag list = root.getList(key, 10);
					if (list == null) {
						continue;
					}
					List<ItemStack> items = new ArrayList<>();
					for (Tag t : list) {
						ItemStack.CODEC.parse(ops, t).result().ifPresent(items::add);
					}
					if (!items.isEmpty()) {
						STASH.put(id, items);
					}
				} catch (Exception ignored) {
				}
			}
		} catch (Exception ignored) {
		}
	}

	/** Gives stashed Soulbound items to the fresh player entity after a death respawn. */
	public static void restore(ServerPlayer newPlayer) {
		MinecraftServer server = newPlayer.getServer();
		if (server == null) {
			return;
		}
		List<ItemStack> stashed = take(server, newPlayer.getUUID());
		if (stashed == null || stashed.isEmpty()) {
			return;
		}
		for (ItemStack stack : stashed) {
			if (!newPlayer.getInventory().add(stack)) {
				net.minecraft.world.level.block.Block.popResource(newPlayer.level(), newPlayer.blockPosition(), stack);
			}
		}
	}
}
