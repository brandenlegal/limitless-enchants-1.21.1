# Limitless Enchants — 1.21.1 backport notes

## Root cause of the "No refMap loaded" crash
The project was built like a 26.x (unobfuscated) mod, but 1.21.1 runs on intermediary names.
- Old build used the plain `fabric-loom` plugin (non-remapping) -> refmap was empty.
- A hand-written empty `limitlessenchants-refmap.json` sat in `src/main/resources` and the mixin
  configs had no `"refmap"` key, so nothing translated `inGround` -> `field_7588` etc.
- Several `method_xxxx` names had been hard-coded to "work around" it, and they were WRONG for 1.21.1
  (e.g. `method_60027` is not the compatibility check, `method_60590` is `getRespawnTarget`).

## What was changed
Build
- `net.fabricmc.fabric-loom-remap` (Loom 1.18), Mojang mappings, Gradle 9.7.1 wrapper added (`./gradlew`).
- Single source set (client code lives in src/main, so `splitEnvironmentSourceSets` could not compile).
- Deleted the stale empty refmap; mixin configs now declare `"refmap": "limitlessenchants-refmap.json"`.
- YACL moved to an optional dependency (it is client-only; hard-depending on it breaks servers).

Mixins (all names are now Mojang names; Loom writes the refmap)
- EnchantmentMixin: `areCompatible`, `getFullname`
- AnvilMenuMixin: 1.21.1 uses `getAbilities().instabuild` (not `hasInfiniteMaterials`) in createResult, so the
  "Too Expensive" cutoff is removed with a `@ModifyConstant` on 40; repair cost hook = `calculateIncreasedRepairCost`
- EnchantmentHelperMixin: dropped the redundant `selectEnchantment` @Overwrite (it was just vanilla)
- AnvilScreenMixin: `renderLabels` (was the 26.x name `extractLabels`)
- EnchantTooltipMixin: `getFullname`
- ReachMixin: `blockInteractionRange` / `entityInteractionRange` (not getBlockReach/getEntityReach)
- Telepathy / TempObsidianDrop / AutoSmelt: `Block.dropResources` and `Block.getDrops` have overloads, so the
  injections now pin the exact descriptor (otherwise Mixin tries every overload and crashes)
- Tree Feller / Vein Miner: action-bar text uses `displayClientMessage` (`sendSystemMessage(..., true)` is NOT an overlay)
- Vein Miner mixin was written but never registered -> the enchant did nothing. It is registered now.
- Removed: PlayerMixin (target doesn't exist in 1.21.1), CreativeTabMixin/Accessor (replaced by Fabric API
  `ItemGroupEvents`), SoulboundRespawnMixin (replaced by Fabric API `ServerPlayerEvents.COPY_FROM`).
- FortuneCropsMixin is fixed but still intentionally NOT registered (add it to limitlessenchants.mixins.json to enable).

Runtime bugs fixed
- `RL` used reflection with unmapped names -> crashed in production. Now calls the vanilla factory directly.
- Enchantment holders were cached forever; after leaving/rejoining a world they went stale and enchants silently
  stopped working. `EnchantHolders` now re-resolves per registry and returns level 0 instead of throwing.
- Recipe used the 1.21.2+ ingredient format; fixed to 1.21.1 (`{"item": ...}`).
- Removed `assets/.../items/enchantment_codex.json` (1.21.4+ format, ignored by 1.21.1).

## Rules for the coding agent (paste into your prompt)
- Target is Minecraft 1.21.1, Fabric, Mojang mappings, REMAPPING Loom. Never write `method_`/`field_` names.
- Never use the non-remapping `fabric-loom` plugin. Never add a hand-written refmap.
- Verify any vanilla method/field against 1.21.1 before using it; do not assume 26.x names exist.
- Mixin targets with overloads must include the full descriptor.
- Prefer Fabric API events over mixins when one exists.
