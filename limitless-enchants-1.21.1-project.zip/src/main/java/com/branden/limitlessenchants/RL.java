package com.branden.limitlessenchants;

import java.lang.reflect.Method;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

/**
 * Creates ResourceLocations without relying on Tiny Remapper
 * to remap the factory method name. Uses reflection to find
 * the method by its intermediary name at runtime.
 */
public class RL {
	private static Method factory;

	static {
		try {
			// Try intermediary name first (production)
			factory = ResourceLocation.class.getMethod("method_60655", String.class, String.class);
		} catch (NoSuchMethodException e) {
			try {
				// Fallback to Mojmap name (dev)
				factory = ResourceLocation.class.getMethod("fromNamespaceAndPath", String.class, String.class);
			} catch (NoSuchMethodException e2) {
				throw new RuntimeException("Cannot find ResourceLocation factory", e2);
			}
		}
	}

	public static ResourceLocation of(String namespace, String path) {
		try {
			return (ResourceLocation) factory.invoke(null, namespace, path);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static ResourceLocation mc(String path) {
		return of("minecraft", path);
	}

	public static ResourceLocation mod(String path) {
		return of("limitlessenchants", path);
	}

	private static Method createRegistryKey;

	static {
		try {
			// Intermediary name for ResourceKey.createRegistryKey
			// Find it via Yarn or use reflection fallback
			createRegistryKey = ResourceKey.class.getMethod("createRegistryKey", ResourceLocation.class);
		} catch (NoSuchMethodException e) {
			throw new RuntimeException("Cannot find ResourceKey.createRegistryKey", e);
		}
	}

	@SuppressWarnings("unchecked")
	public static <T> ResourceKey<T> registryKey(String namespace, String path) {
		try {
			return (ResourceKey<T>) createRegistryKey.invoke(null, of(namespace, path));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> ResourceKey<T> mcRegistry(String path) {
		return registryKey("minecraft", path);
	}
}
