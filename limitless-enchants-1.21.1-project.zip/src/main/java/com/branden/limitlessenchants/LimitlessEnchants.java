package com.branden.limitlessenchants;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LimitlessEnchants implements ModInitializer {
	public static final String MOD_ID = "limitlessenchants";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static Item ENCHANTMENT_CODEX;

	@Override
	public void onInitialize() {
		LOGGER.info("Limitless Enchants loaded: anvil limits, enchanting-table caps and enchantment level caps removed.");
		// Load config (per-enchantment toggles + tuning).
		ModConfig.load();
		// Enchantment Codex item.
		ENCHANTMENT_CODEX = new CodexItem(new Item.Properties());
		Registry.register(BuiltInRegistries.ITEM,
				RL.of(MOD_ID, "enchantment_codex"),
				ENCHANTMENT_CODEX);
	}
}
