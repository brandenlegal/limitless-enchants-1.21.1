package com.branden.limitlessenchants.client;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import com.branden.limitlessenchants.RL;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;

/**
 * Enchantment Codex — a wizard's lived-in journal for 1.21.1.
 * Vanilla Screen: book texture, two-page spreads, typewriter text reveal,
 * handwritten marginalia, and page-turn sounds.
 */
@Environment(EnvType.CLIENT)
public class CodexBookScreen extends Screen {
	private static final ResourceLocation BOOK_TEXTURE = RL.of("limitlessenchants",
			"textures/gui/codex_book.png");
	private static final int BOOK_W = 288;
	private static final int BOOK_H = 288;
	private static final int TEX_SIZE = 384;
	private static final int LINE_HEIGHT = 12;
	private static final int PAGE_TOP = 52;
	private static final int LEFT_X = 56;
	private static final int RIGHT_X = 152;
	private static final int PAGE_WIDTH = 76;
	private static final int MAX_LINES = 14;
	private static final int TICKS_PER_LINE = 2;

	private static final String[][] ENCHANTS = {
			{ "Excavator", "Carve through stone like butter. 3x3 mining, deeper per level." },
			{ "Auto-Smelt", "The furnace follows your pick. Ores drop smelted." },
			{ "Lifesteal", "Every hit feeds you. Their health becomes yours." },
			{ "Thunderstrike", "Sometimes the sky agrees with you. Lightning on hit." },
			{ "Vein Miner", "One ore is a promise. Mines the whole vein." },
			{ "Telepathy", "Drops fly straight to your inventory." },
			{ "Tree Feller", "One swing, one tree. Timber!" },
			{ "Soulbound", "Death can't have it. Stays with you." },
			{ "Magnet", "Why walk to drops when they walk to you?" },
			{ "Seeker", "Arrows that find their target." },
			{ "Poison Aspect", "Your blade carries extra malice." },
			{ "Phoenix", "Death is a suggestion. Rise in flames." },
			{ "Beheader", "For the collector. Heads will roll." },
			{ "Adrenaline", "Speed surges after every kill." },
			{ "Execute", "No mercy for the weak. Huge damage under 20% HP." },
			{ "Sear", "Your sword is a grill. Mobs drop dinner." },
			{ "Lava Walker", "Lava is spicy water on obsidian feet." },
			{ "Dodge", "You were never there. Attacks phase through." },
			{ "Bulwark", "A wall you wear. Damage breaks on it first." },
			{ "Harvest", "Reap and replant in one motion." },
			{ "Frostbite", "Winter follows your blade. Slow, freeze, fall." },
			{ "Reach", "Your arms are longer than they look." },
	};

	/** Handwritten margin notes — one per spread, in the author's voice. */
	private static final String[] MARGINALIA = {
			"started this book after my 3rd anvil broke. never again.",
			"dug straight to bedrock testing excavator. oops.",
			"vein miner + fortune = actually illegal",
			"telepathy saved my diamonds from lava. twice.",
			"do NOT test thunderstrike near your house",
			"phoenix proc'd during a raid. my heart stopped.",
			"beheader finally got me a wither skull. first try!",
			"sear + pig farm = infinite bacon. you're welcome.",
			"lava walker is just showing off and i love it",
			"dodge feels like cheating. it is. that's the point.",
			"bulwark tanked the warden. BARELY.",
			"reach lets me steal from villagers through walls. sorry.",
	};

	private final List<List<Component>> leftSpreads = new ArrayList<>();
	private final List<List<Component>> rightSpreads = new ArrayList<>();
	private int currentSpread;
	private int revealedLines;
	private int tickCounter;
	private Button prevButton;
	private Button nextButton;
	private Button configButton;

	public CodexBookScreen() {
		super(Component.literal("Enchantment Codex"));
		buildSpreads();
	}

	private List<Component> wrap(String text, Style style) {
		List<Component> out = new ArrayList<>();
		Minecraft mc = Minecraft.getInstance();
		String[] words = text.split(" ");
		StringBuilder line = new StringBuilder();
		for (String word : words) {
			String test = line.length() == 0 ? word : line + " " + word;
			if (mc.font.width(test) > PAGE_WIDTH) {
				if (line.length() > 0) {
					out.add(Component.literal(line.toString()).withStyle(style));
					line = new StringBuilder(word);
				} else {
					out.add(Component.literal(word).withStyle(style));
				}
			} else {
				line = new StringBuilder(test);
			}
		}
		if (line.length() > 0) {
			out.add(Component.literal(line.toString()).withStyle(style));
		}
		return out;
	}

	private void buildSpreads() {
		Style titleStyle = Style.EMPTY.withBold(true).withColor(ChatFormatting.DARK_PURPLE);
		Style bodyStyle = Style.EMPTY.withColor(ChatFormatting.DARK_GRAY);
		Style marginStyle = Style.EMPTY.withItalic(true).withColor(ChatFormatting.GRAY);

		for (int i = 0; i < ENCHANTS.length; i += 2) {
			List<Component> left = new ArrayList<>();
			left.add(Component.literal(ENCHANTS[i][0]).withStyle(titleStyle));
			left.add(Component.literal(""));
			left.addAll(wrap(ENCHANTS[i][1], bodyStyle));
			// Marginalia at bottom of left page
			int marginIdx = i / 2;
			if (marginIdx < MARGINALIA.length) {
				while (left.size() < MAX_LINES - 2) {
					left.add(Component.literal(""));
				}
				left.add(Component.literal(""));
				left.addAll(wrap("* " + MARGINALIA[marginIdx], marginStyle));
			}
			leftSpreads.add(left);

			List<Component> right = new ArrayList<>();
			if (i + 1 < ENCHANTS.length) {
				right.add(Component.literal(ENCHANTS[i + 1][0]).withStyle(titleStyle));
				right.add(Component.literal(""));
				right.addAll(wrap(ENCHANTS[i + 1][1], bodyStyle));
			}
			rightSpreads.add(right);
		}
	}

	@Override
	protected void init() {
		int x = (this.width - BOOK_W) / 2;
		int y = (this.height - BOOK_H) / 2;

		prevButton = Button.builder(Component.literal("<"), b -> {
			if (currentSpread > 0) {
				currentSpread--;
				revealedLines = 0;
				tickCounter = 0;
				playPageTurn();
			}
		}).bounds(x + 20, y + BOOK_H - 30, 20, 20).build();

		nextButton = Button.builder(Component.literal(">"), b -> {
			if (currentSpread < leftSpreads.size() - 1) {
				currentSpread++;
				revealedLines = 0;
				tickCounter = 0;
				playPageTurn();
			}
		}).bounds(x + BOOK_W - 40, y + BOOK_H - 30, 20, 20).build();

		configButton = Button.builder(Component.literal("Config"), b -> {
			Minecraft.getInstance().setScreen(ModConfigScreen.create(this));
		}).bounds(x + BOOK_W / 2 - 30, y + BOOK_H - 30, 60, 20).build();

		addRenderableWidget(prevButton);
		addRenderableWidget(nextButton);
		addRenderableWidget(configButton);
	}

	private void playPageTurn() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player != null) {
			mc.player.playSound(SoundEvents.BOOK_PAGE_TURN, 1.0F, 1.0F);
		}
	}

	@Override
	public void tick() {
		tickCounter++;
		if (tickCounter >= TICKS_PER_LINE) {
			tickCounter = 0;
			int maxLines = Math.max(
				currentSpread < leftSpreads.size() ? leftSpreads.get(currentSpread).size() : 0,
				currentSpread < rightSpreads.size() ? rightSpreads.get(currentSpread).size() : 0
			);
			if (revealedLines < maxLines) {
				revealedLines++;
			}
		}
	}

	@Override
	public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
		renderBackground(gfx, mouseX, mouseY, partialTick);
		int x = (this.width - BOOK_W) / 2;
		int y = (this.height - BOOK_H) / 2;

		// Book texture
		gfx.blit(BOOK_TEXTURE, x, y, 0.0F, 0.0F, BOOK_W, BOOK_H, TEX_SIZE, TEX_SIZE);

		// Left page
		if (currentSpread < leftSpreads.size()) {
			List<Component> lines = leftSpreads.get(currentSpread);
			int showLines = Math.min(revealedLines, lines.size());
			for (int i = 0; i < showLines && i < MAX_LINES; i++) {
				gfx.drawString(font, lines.get(i), x + LEFT_X, y + PAGE_TOP + i * LINE_HEIGHT, 0xFFFFFF);
			}
		}

		// Right page
		if (currentSpread < rightSpreads.size()) {
			List<Component> lines = rightSpreads.get(currentSpread);
			int showLines = Math.min(revealedLines, lines.size());
			for (int i = 0; i < showLines && i < MAX_LINES; i++) {
				gfx.drawString(font, lines.get(i), x + RIGHT_X, y + PAGE_TOP + i * LINE_HEIGHT, 0xFFFFFF);
			}
		}

		// Page indicator (below buttons, not overlapping)
		String indicator = (currentSpread + 1) + " / " + leftSpreads.size();
		gfx.drawCenteredString(font, indicator, x + BOOK_W / 2, y + BOOK_H - 12, 0x808080);

		super.render(gfx, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
