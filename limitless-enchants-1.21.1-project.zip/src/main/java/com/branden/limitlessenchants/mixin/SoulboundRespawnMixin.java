package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.SoulboundStash;
import java.util.List;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Restores Soulbound items to the fresh player entity after death respawn.
 * (The dying entity is discarded, so the stash is keyed by UUID.)
 */
@Mixin(ServerPlayer.class)
public class SoulboundRespawnMixin {
	@Inject(method = "method_60590", at = @At("TAIL"))
	private void limitless$soulboundRespawn(ServerPlayer oldPlayer, boolean alive, CallbackInfo ci) {
		if (alive) {
			return; // returning from the End, not a death
		}
		ServerPlayer self = (ServerPlayer) (Object) this;
		List<ItemStack> stashed = SoulboundStash.take(
				((net.minecraft.server.level.ServerLevel) self.level()).getServer(), self.getUUID());
		if (stashed == null || stashed.isEmpty()) {
			return;
		}
		for (ItemStack stack : stashed) {
			if (!self.getInventory().add(stack)) {
				Block.popResource(self.level(), self.blockPosition(), stack);
			}
		}
	}
}
