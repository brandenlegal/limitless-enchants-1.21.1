package com.branden.limitlessenchants.mixin;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Removes the anvil's limits:
 * - no more "Too Expensive!" (any XP cost is allowed),
 * - enchantment levels can merge past the vanilla maximum (Sharpness V + Sharpness V = Sharpness VI, ...),
 * - the prior-work penalty no longer grows, so repeated anvil uses never snowball in cost.
 */
@Mixin(AnvilMenu.class)
public class AnvilMenuMixin {
	// createResult() voids the output when `cost >= 40` unless the player has infinite
	// materials. The second hasInfiniteMaterials() call in createResult() is that guard
	// (the first one is the creative-mode bypass inside the merge loop, which we keep).
	// Forcing it to true removes the cutoff without touching anything else.
	@Redirect(
		method = "createResult",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/entity/player/Player;hasInfiniteMaterials()Z",
			ordinal = 1
		)
	)
	private boolean limitless$removeTooExpensiveCutoff(Player player) {
		return true;
	}

	// createResult() clamps merged levels with `if (level > enchantment.getMaxLevel())`.
	// Returning the game's hard level ceiling (255, the most ItemEnchantments can
	// store) removes the vanilla clamp so levels can grow far past e.g. Sharpness V.
	@Redirect(
		method = "createResult",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/enchantment/Enchantment;getMaxLevel()I"
		)
	)
	private int limitless$noMaxLevelCap(Enchantment enchantment) {
		return Enchantment.MAX_LEVEL;
	}

	// Vanilla doubles the repair cost (plus one) after every anvil operation and adds it
	// to the XP price, which is what makes costs snowball. Keep it flat instead.
	@Inject(method = "method_48350", at = @At("HEAD"), cancellable = true)
	private static void limitless$flatRepairCost(int baseCost, CallbackInfoReturnable<Integer> cir) {
		cir.setReturnValue(baseCost);
	}

	// Universal enchanting: any item can be used in the anvil, not just
	// items the game considers enchantable.
	@Redirect(
		method = "createResult",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/enchantment/EnchantmentHelper;canStoreEnchantments(Lnet/minecraft/world/item/ItemStack;)Z"
		)
	)
	private static boolean limitless$anyItemInAnvil(ItemStack itemStack) {
		return true;
	}
}
