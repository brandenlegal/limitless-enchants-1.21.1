package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.LimitlessEnchants;
import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.core.registries.BuiltInRegistries;
import com.branden.limitlessenchants.RL;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds the Enchantment Codex to the Ingredients creative tab.
 * Uses accessor for intermediary field access.
 */
@Mixin(CreativeModeTab.class)
public class CreativeTabMixin {
	@Inject(method = "buildContents", at = @At("TAIL"))
	private void limitless$addCodex(CreativeModeTab.ItemDisplayParameters params, CallbackInfo ci) {
		CreativeModeTab self = (CreativeModeTab) (Object) this;
		CreativeModeTab ingredients = BuiltInRegistries.CREATIVE_MODE_TAB.get(
				RL.of("minecraft", "ingredients"));
		if (self == ingredients && LimitlessEnchants.ENCHANTMENT_CODEX != null) {
			CreativeTabAccessor accessor = (CreativeTabAccessor) this;
			Collection<ItemStack> displayItems = accessor.getDisplayItems();
			Collection<ItemStack> mutable = displayItems instanceof ArrayList
					? displayItems
					: new ArrayList<>(displayItems);
			mutable.add(new ItemStack(LimitlessEnchants.ENCHANTMENT_CODEX));
			accessor.setDisplayItems(mutable);
		}
	}
}
