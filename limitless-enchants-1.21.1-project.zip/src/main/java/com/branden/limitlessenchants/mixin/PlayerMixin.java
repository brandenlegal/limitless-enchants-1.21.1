package com.branden.limitlessenchants.mixin;

import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Lets axes perform sweep attacks like swords, so Sweeping Edge works on axes.
 */
@Mixin(Player.class)
public class PlayerMixin {
	// isSweepAttack() ends with `getItemInHand(MAIN_HAND).is(ItemTags.SWORDS)` —
	// the only ItemStack.is(TagKey) call in the method. Accept axes too.
	@Redirect(
		method = "isSweepAttack",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/tags/TagKey;)Z"
		)
	)
	private boolean limitless$sweepWithAxes(ItemStack stack, TagKey<Item> tag) {
		return stack.is(tag) || stack.is(ItemTags.AXES);
	}
}
