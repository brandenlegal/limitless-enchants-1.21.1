package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.ModConfig;
import com.branden.limitlessenchants.TempObsidianTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import com.branden.limitlessenchants.RL;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Telepathy: mined blocks drop straight into the player's inventory instead
 * of popping out as item entities. If the inventory is full, the remainder
 * drops normally. Composes with Auto-Smelt (drops are smelted first).
 */
@Mixin(Block.class)
public class TelepathyMixin {
	@Unique
	private static Holder<Enchantment> limitless$telepathy;

	@Inject(
		method = "dropResources",
		at = @At("HEAD"),
		cancellable = true
	)
	private static void limitless$telepathyDrops(BlockState state, Level level, BlockPos pos,
			BlockEntity blockEntity, Entity breaker, ItemStack tool, CallbackInfo ci) {
		if (!(level instanceof ServerLevel serverLevel)) {
			return;
		}
		if (!(breaker instanceof ServerPlayer player)) {
			return;
		}
		if (!ModConfig.isEnabled("telepathy")) {
			return;
		}
		// Temp obsidian from Lava Walker must never be telepathied into the inventory —
		// that's the infinite-obsidian farm. (Ordering: this runs before TempObsidianDropMixin.)
		if (TempObsidianTracker.isTemp(serverLevel.dimension(), pos)) {
			return;
		}
		if (EnchantmentHelper.getItemEnchantmentLevel(limitless$telepathyHolder(serverLevel), tool) <= 0) {
			return;
		}
		// Same drops vanilla would give (Auto-Smelt/Fortune apply via getDrops),
		// but they go into the inventory instead of spawning as entities.
		for (ItemStack stack : Block.getDrops(state, serverLevel, pos, blockEntity, breaker, tool)) {
			if (!player.getInventory().add(stack) && !stack.isEmpty()) {
				Block.popResource(level, pos, stack);
			}
		}
		state.spawnAfterBreak(serverLevel, pos, tool, true);
		ci.cancel();
	}

	@Unique
	private static Holder<Enchantment> limitless$telepathyHolder(ServerLevel level) {
		if (limitless$telepathy == null) {
			Registry<Enchantment> registry = level.registryAccess().registryOrThrow(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")));
			limitless$telepathy = registry.getHolderOrThrow(ResourceKey.create(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")),
					RL.of("limitlessenchants", "telepathy")));
		}
		return limitless$telepathy;
	}
}
