package com.branden.limitlessenchants.mixin;

import java.util.Collection;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(CreativeModeTab.class)
public interface CreativeTabAccessor {
	@Accessor("field_40859")
	Collection<ItemStack> getDisplayItems();

	@Accessor("field_40859")
	void setDisplayItems(Collection<ItemStack> items);
}
