package com.branden.limitlessenchants.mixin.client;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.item.enchantment.Enchantment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * The one tooltip rework: enchantment levels pushed past the vanilla max
 * render in gold. Hooks getFullname (RETURN) instead of replacing
 * addToTooltip, so vanilla tooltips and Enchantment Descriptions keep working.
 */
@Mixin(Enchantment.class)
public class EnchantTooltipMixin {
	private static final int LIMITLESS_COLOR = 0xFFC94D;

	@Inject(method = "method_8179", at = @At("RETURN"), cancellable = true)
	private static void limitless$goldOverMaxLevel(Holder<Enchantment> enchantment, int level,
			CallbackInfoReturnable<Component> cir) {
		Enchantment e = enchantment.value();
		if (level <= e.getMaxLevel()) {
			return; // vanilla stands
		}
		// Rebuild exactly like vanilla, but the level shines gold.
		MutableComponent name = e.description().copy();
		if (enchantment.is(EnchantmentTags.CURSE)) {
			ComponentUtils.mergeStyles(name, Style.EMPTY.withColor(ChatFormatting.RED));
		} else {
			ComponentUtils.mergeStyles(name, Style.EMPTY.withColor(ChatFormatting.GRAY));
		}
		if (level != 1 || e.getMaxLevel() != 1) {
			name.append(CommonComponents.SPACE)
					.append(Component.literal(limitless$toRoman(level))
							.withStyle(Style.EMPTY.withColor(LIMITLESS_COLOR).withBold(true)));
		}
		cir.setReturnValue(name);
	}

	/** Roman numerals for every level — vanilla lang only covers 1-10. */
	private static String limitless$toRoman(int level) {
		int[] values = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
		String[] numerals = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
		StringBuilder sb = new StringBuilder();
		int n = level;
		for (int i = 0; i < values.length; i++) {
			while (n >= values[i]) {
				sb.append(numerals[i]);
				n -= values[i];
			}
		}
		return sb.toString();
	}
}
