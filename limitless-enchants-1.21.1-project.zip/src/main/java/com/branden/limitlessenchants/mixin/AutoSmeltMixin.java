package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.ModConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import com.branden.limitlessenchants.RL;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Auto-Smelt: blocks broken with an Auto-Smelt-enchanted tool drop their
 * furnace-smelted results instead of the raw drops. Only non-block items are
 * smelted, so cobblestone stays cobblestone and sand stays sand — but raw
 * iron becomes iron ingots, raw gold becomes gold ingots, etc. Works with
 * Fortune (all the extra raw drops get smelted) and composes with Excavator.
 */
@Mixin(Block.class)
public class AutoSmeltMixin {
	@Unique
	private static Holder<Enchantment> limitless$autoSmelt;

	// Target the tool-aware overload specifically.
	@Inject(
		method = "getDrops",
		at = @At("RETURN"),
		cancellable = true
	)
	private static void limitless$autoSmeltDrops(BlockState state, ServerLevel level, BlockPos pos,
			BlockEntity blockEntity, Entity breaker, ItemStack tool,
			CallbackInfoReturnable<List<ItemStack>> cir) {
		List<ItemStack> drops = cir.getReturnValue();
		if (drops.isEmpty()) {
			return;
		}
		if (!ModConfig.isEnabled("auto_smelt")) {
			return;
		}
		if (EnchantmentHelper.getItemEnchantmentLevel(limitless$autoSmeltHolder(level), tool) <= 0) {
			return;
		}
		List<ItemStack> smelted = new ArrayList<>(drops.size());
		boolean changed = false;
		for (ItemStack drop : drops) {
			ItemStack result = limitless$smeltDrop(level, drop);
			smelted.add(result);
			if (result != drop) {
				changed = true;
			}
		}
		if (changed) {
			cir.setReturnValue(smelted);
		}
	}

	// Cache smelt results per item — Excavator breaks 45 blocks per swing,
	// and each one was doing a full recipe lookup. Bounded (vanilla item count).
	@Unique
	private static final java.util.Map<net.minecraft.world.item.Item, java.util.Optional<ItemStack>> LIMITLESS$SMELT_CACHE =
			new java.util.HashMap<>();

	private static ItemStack limitless$smeltDrop(ServerLevel level, ItemStack drop) {
		if (drop.isEmpty() || drop.getItem() instanceof BlockItem) {
			return drop;
		}
		java.util.Optional<ItemStack> cached = LIMITLESS$SMELT_CACHE.get(drop.getItem());
		if (cached == null) {
			Optional<RecipeHolder<SmeltingRecipe>> recipe = level.getServer().getRecipeManager()
					.getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(drop), level);
			ItemStack result = ItemStack.EMPTY;
			if (recipe.isPresent()) {
				result = recipe.get().value().assemble(new SingleRecipeInput(drop), level.registryAccess());
			}
			cached = result.isEmpty() ? java.util.Optional.empty() : java.util.Optional.of(result);
			// Bound the cache — vanilla has < 2000 items, but datapacks can add more.
			if (LIMITLESS$SMELT_CACHE.size() < 4096) {
				LIMITLESS$SMELT_CACHE.put(drop.getItem(), cached);
			}
		}
		if (cached.isEmpty()) {
			return drop;
		}
		ItemStack result = cached.get().copy();
		result.setCount(drop.getCount());
		return result;
	}

	@Unique
	private static Holder<Enchantment> limitless$autoSmeltHolder(ServerLevel level) {
		if (limitless$autoSmelt == null) {
			Registry<Enchantment> registry = level.registryAccess().registryOrThrow(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")));
			limitless$autoSmelt = registry.getHolderOrThrow(ResourceKey.create(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")),
					RL.of("limitlessenchants", "auto_smelt")));
		}
		return limitless$autoSmelt;
	}
}
