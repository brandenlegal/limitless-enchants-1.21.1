package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.EnchantHolders;
import com.branden.limitlessenchants.ModConfig;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Reach (tools): +1 block interaction range and +1 entity reach per level.
 * Checks the held item. Runs on both sides — the client needs it to even
 * attempt breaking blocks beyond vanilla range.
 */
@Mixin(Player.class)
public class ReachMixin {
	@Inject(method = "getBlockReach", at = @At("RETURN"), cancellable = true)
	private void limitless$blockReach(CallbackInfoReturnable<Double> cir) {
		Player self = (Player) (Object) this;
		ItemStack held = self.getMainHandItem();
		int reach = ModConfig.isEnabled("reach") ? EnchantHolders.level(self.level(), "reach", held) : 0;
		if (reach > 0) {
			cir.setReturnValue(cir.getReturnValue() + reach);
		}
	}

	@Inject(method = "getEntityReach", at = @At("RETURN"), cancellable = true)
	private void limitless$entityReach(CallbackInfoReturnable<Double> cir) {
		Player self = (Player) (Object) this;
		ItemStack held = self.getMainHandItem();
		int reach = ModConfig.isEnabled("reach") ? EnchantHolders.level(self.level(), "reach", held) : 0;
		if (reach > 0) {
			cir.setReturnValue(cir.getReturnValue() + reach);
		}
	}
}
