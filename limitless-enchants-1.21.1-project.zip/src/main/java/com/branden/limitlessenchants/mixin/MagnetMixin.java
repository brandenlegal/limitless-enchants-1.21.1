package com.branden.limitlessenchants.mixin;

import com.branden.limitlessenchants.ModConfig;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import com.branden.limitlessenchants.RL;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Magnet (boots): nearby dropped items are pulled toward the player.
 * Radius scales with level (6 / 8 / 10 blocks). Freshly dropped items
 * get a short grace period so throwing something doesn't yank it back.
 */
@Mixin(ServerPlayer.class)
public abstract class MagnetMixin {
	@Unique
	private static final EquipmentSlot[] ARMOR_SLOTS = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
			EquipmentSlot.FEET };

	@Unique
	private Holder<Enchantment> limitless$magnet;

	@Inject(method = "tick", at = @At("RETURN"))
	private void limitless$magnetPull(CallbackInfo ci) {
		ServerPlayer self = (ServerPlayer) (Object) this;
		// Every tick with small increments = smooth glide instead of lag-steps.
		ServerLevel serverLevel = (ServerLevel) self.level();
		int magnetLevel = 0;
		if (ModConfig.isEnabled("magnet")) {
			for (EquipmentSlot slot : ARMOR_SLOTS) {
				magnetLevel = Math.max(magnetLevel, EnchantmentHelper
						.getItemEnchantmentLevel(limitless$magnetHolder(serverLevel), self.getItemBySlot(slot)));
			}
		}
		if (magnetLevel <= 0) {
			return;
		}
		double radius = ModConfig.get().magnetBaseRadius + 2.0 * (magnetLevel - 1);
		AABB box = self.getBoundingBox().inflate(radius);
		List<ItemEntity> items = serverLevel.getEntitiesOfClass(ItemEntity.class, box);
		Vec3 playerPos = self.position().add(0.0, 0.5, 0.0);
		for (ItemEntity item : items) {
			// Grace period so freshly dropped/thrown items aren't yanked back.
			if (item.isRemoved() || item.getAge() < 20) {
				continue;
			}
			Vec3 toPlayer = playerPos.subtract(item.position());
			double distance = toPlayer.length();
			if (distance < 0.5) {
				continue;
			}
			Vec3 pull = toPlayer.normalize().scale(0.015 + distance * 0.002);
			Vec3 motion = item.getDeltaMovement().add(pull);
			if (motion.length() > 0.35) {
				motion = motion.normalize().scale(0.35);
			}
			item.setDeltaMovement(motion.x, motion.y + 0.008, motion.z);
		}
	}

	@Unique
	private Holder<Enchantment> limitless$magnetHolder(ServerLevel level) {
		if (limitless$magnet == null) {
			Registry<Enchantment> registry = level.registryAccess().registryOrThrow(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")));
			limitless$magnet = registry.getHolderOrThrow(ResourceKey.create(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")),
					RL.of("limitlessenchants", "magnet")));
		}
		return limitless$magnet;
	}
}
