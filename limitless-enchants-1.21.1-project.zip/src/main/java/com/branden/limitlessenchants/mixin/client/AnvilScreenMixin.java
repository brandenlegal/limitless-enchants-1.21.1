package com.branden.limitlessenchants.mixin.client;

import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * The server no longer voids anvil results at 40+ levels, so the screen should
 * not paint "Too Expensive!" either — it now just shows the real level cost.
 */
@Mixin(AnvilScreen.class)
public class AnvilScreenMixin {
	@ModifyConstant(method = "extractLabels", constant = @Constant(intValue = 40))
	private int limitless$noTooExpensiveLabel(int original) {
		return Integer.MAX_VALUE;
	}
}
