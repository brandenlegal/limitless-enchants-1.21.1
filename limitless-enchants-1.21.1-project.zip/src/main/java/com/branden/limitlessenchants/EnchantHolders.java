package com.branden.limitlessenchants;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Caches Holder<Enchantment> lookups by ID so mixins don't re-resolve
 * the registry every hit.
 */
public final class EnchantHolders {
	private EnchantHolders() {
	}

	private static final Map<String, Holder<Enchantment>> CACHE = new ConcurrentHashMap<>();

	public static Holder<Enchantment> get(Level level, String path) {
		Holder<Enchantment> cached = CACHE.get(path);
		if (cached != null) {
			return cached;
		}
		Registry<Enchantment> registry = level.registryAccess().registryOrThrow(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")));
		Holder<Enchantment> holder = registry.getHolderOrThrow(ResourceKey.create(ResourceKey.createRegistryKey(RL.of("minecraft", "enchantment")),
				RL.of("limitlessenchants", path)));
		CACHE.put(path, holder);
		return holder;
	}

	@SuppressWarnings("unchecked")
	public static Holder<Enchantment> get(ServerLevel level, String path) {
		return get((Level) level, path);
	}

	public static int level(Level level, String path, ItemStack stack) {
		if (stack.isEmpty()) {
			return 0;
		}
		return EnchantmentHelper.getItemEnchantmentLevel(get(level, path), stack);
	}

	public static int level(ServerLevel level, String path, ItemStack stack) {
		return level((Level) level, path, stack);
	}
}
